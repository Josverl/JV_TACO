# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this file is to throw an error message that it is deprecated or there is equivalent cmdlets that do the work

function Invoke-CsDeprecatedError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Error action.
        ${DeprecatedErrorMessage},

        [Parameter(Mandatory=$false)]
        [System.Collections.Hashtable]
        $PropertyBag
    )

    process {
        Write-Error -Message $DeprecatedErrorMessage
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format enum of the cmdlet output

class ProcessedGetOnlineEnhancedEmergencyServiceDisclaimerResponse {
    [string]$Country
    [string]$Version
    [string]$Content
    [string]$Response
    [string]$RespondedByObjectId
    [DateTime]$ResponseTimestamp
    [string]$CorrelationId
    [string]$Locale
}

function Get-CsOnlineEnhancedEmergencyServiceDisclaimerModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # CountryOrRegion of the Emergency Disclaimer
        ${CountryOrRegion},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Version of the Emergency Disclaimer
        ${Version}
    )

    process {
        
        $edresponse = ''
        
        try
        {
            
            $input = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineEnhancedEmergencyServiceDisclaimer @PSBoundParameters -ErrorAction Stop

            if ($input -ne $null -and $input.Response -ne $null)
            {
                switch ($input.Response)
                {
                    0 {$edresponse = 'None'}
                    1 {$edresponse = 'Accepted'}
                    2 {$edresponse = 'NotAccepted'}
                }

                $result = [ProcessedGetOnlineEnhancedEmergencyServiceDisclaimerResponse]::new()
                $result.Content = $input.Content
                $result.CorrelationId = $input.CorrelationId
                $result.Country = $input.Country
                $result.Locale = $input.Locale
                $result.RespondedByObjectId = $input.RespondedByObjectId
                $result.Response = $edresponse
                $result.ResponseTimestamp = $input.ResponseTimestamp
                $result.Version = $input.Version

                return $result   
            }
        }
        catch
        {
            Write-Host $_
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Provide option to Accept or Reject Disclaimer

class ProcessedSetOnlineEnhancedEmergencyServiceDisclaimerResponse {
    [string]$Country
    [string]$Version
    [string]$Content
    [string]$Response
    [string]$RespondedByObjectId
    [DateTime]$ResponseTimestamp
    [string]$CorrelationId
    [string]$Locale
}

function Set-CsOnlineEnhancedEmergencyServiceDisclaimerModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # CountryOrRegion of the Emergency Disclaimer
        ${CountryOrRegion},
        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # Version of the Emergency Disclaimer
        ${Version},
        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # ForceAccept Emergency Disclaimer, Disclaimer will pop up without this parameter provided
        ${ForceAccept},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Response of the Emergency Disclaimer
        ${Response},
        [Parameter(Mandatory=$false)]
        [System.String]
        # RespondedByObjectId of the Emergency Disclaimer
        ${RespondedByObjectId},
        [Parameter(Mandatory=$false)]
        [System.String]
        # ResponseTimestamp of the Emergency Disclaimer
        ${ResponseTimestamp},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Locale of the Emergency Disclaimer
        ${Locale}
    )

    process {

        $ged = $null
        $edContent = $null
        $edCountry = $null
        $edVersion = $null
        $edResponse = $null
        $edRespondedByObjectId = $null
        $edResponseTimestamp = $null
        $edLocale = $null

        try
        {
            $ged = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineEnhancedEmergencyServiceDisclaimer @PSBoundParameters -ErrorAction Stop
            $edContent = Out-String -InputObject $ged.Content
            $edCountry = Out-String -InputObject $ged.Country
            $edVersion = Out-String -InputObject $ged.Version
            $edResponse = Out-String -InputObject $ged.Response
            $edRespondedByObjectId = Out-String -InputObject $ged.RespondedByObjectId
            $edResponseTimestamp = [DateTime]::UtcNow.ToString('u')
            $edLocale = Out-String -InputObject $ged.Locale

            if ([string]::IsNullOrEmpty($edContent))
            {
                $DiagnosticCode = Out-String -InputObject $ged.DiagnosticCode
                $DiagnosticCorrelationId = Out-String -InputObject $ged.DiagnosticCorrelationId
                #$DiagnosticDebugContent = Out-String -InputObject $ged.DiagnosticDebugContent
                $DiagnosticGenevaLogsUrl = Out-String -InputObject $ged.DiagnosticGenevaLogsUrl
                $DiagnosticReason = Out-String -InputObject $ged.DiagnosticReason
                $DiagnosticSubCode = Out-String -InputObject $ged.DiagnosticSubCode
                
                Write-Host "DiagnosticCode : "$DiagnosticCode
                Write-Host "DiagnosticCorrelationId :" $DiagnosticCorrelationId
                #Write-Host $DiagnosticDebugContent
                Write-Host "DiagnosticGenevaLogsUrl : " $DiagnosticGenevaLogsUrl
                Write-Host "DiagnosticReason : " $DiagnosticReason
                Write-Host "DiagnosticSubCode : "$DiagnosticSubCode
                Return
            }
        } catch {
            throw
        }
        
        if(!${ForceAccept})
        {
            $confirmation = Read-Host $edContent"`n[Y] Yes  [N] No  (default is `"N`")"
            switch($confirmation) {
                'Y' {
                    Break
                }
                Default {
                Return
                }
            }

        } else {
            $null = $PSBoundParameters.Remove('ForceAccept')
        }

        try {

            [System.String[]]$global:configscopes = @("48ac35b8-9aa8-4d74-927d-1f4a14a0b239/user_impersonation")
            
            Write-Host "Timestamp " $edResponseTimestamp

            $edResponse = 1

            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineEnhancedEmergencyServiceDisclaimer -Country ${CountryOrRegion} -Version ${Version} -Content $edContent -Response $edResponse -RespondedByObjectId $edRespondedByObjectId  -ResponseTimestamp $edResponseTimestamp -Locale ${Locale}  -ErrorAction Stop
        } catch {
            throw
        }   
            
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsConfigurationModern {
    [CmdletBinding(DefaultParameterSetName = 'ConfigType')]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='ConfigType')]
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [Parameter(Mandatory=$true, ParameterSetName='Filter')]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        # Name of configuration retrieved.
        ${Identity},

        [Parameter(Mandatory=$true, ParameterSetName='Filter')]
        [System.String]
        # Name of configuration retrieved.
        ${Filter},

        [Parameter(Mandatory=$false)]
        [System.Collections.Hashtable]
        ${PropertyBag}
    )

    process {
        $xdsConfigurationOutput0 = $null

        $HashArguments = @{ ConfigType = $ConfigType}

        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $HashArguments.Add('ConfigName', $Identity)
        }

        $TeamsMeetingBroadcastConfiguration_FixupFormat = $false

        if($PropertyBag -ne $null)
        {
            if($ConfigType -eq 'TeamsMeetingBroadcastConfiguration')
            {
                if($PropertyBag['ExposeSDNConfigurationJsonBlob'] -eq $true)
                {
                    $TeamsMeetingBroadcastConfiguration_FixupFormat = $true
                    $HashArguments.Add('HttpPipelinePrepend', { param($req, $callback, $next )  $req.RequestUri = [Uri]($req.RequestUri.ToString() + '?ExposeSDNConfigurationJsonBlob=true'); return $next.SendAsync($req, $callback); })
                }
            }
            else
            {
                #ignore
            }
        }

        $xdsConfigurationOutput0 = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsConfiguration @HashArguments

        $xdsConfigurationOutput = ($xdsConfigurationOutput0 | %{
            Convert-PsCustomObjectToPsObject (ConvertFrom-Json -InputObject $_)
        })

        if (![string]::IsNullOrWhiteSpace($Filter))
        {
            $xdsConfigurationOutput = $xdsConfigurationOutput | Where-Object {($_.Identity -Like "$Filter") -or ($_.Identity -Like "Tag:$Filter")}
        }

        $xdsConfigurationOutput = $xdsConfigurationOutput | %{ Set-FormatOnConfigObject -ConfigObject $_ -ConfigType $ConfigType }

        if($ConfigType -eq 'TenantFederationSettings')
        {
            $xdsConfigurationOutput = $xdsConfigurationOutput | %{ Convert-PsCustomObjectToPsObject (Set-FixTenantFedConfigObject -ConfigObject $_) }
        }

        if($ConfigType -eq 'OnlinePSTNGateway')
        {
            $xdsConfigurationOutput = $xdsConfigurationOutput | %{ Convert-PsCustomObjectToPsObject (Set-FixTypoInOnlinePSTNGatewayConfigObject -ConfigObject $_) }
        }

        if($TeamsMeetingBroadcastConfiguration_FixupFormat)
        {
            #why are we special handling this? when legacy is run, the format type name is sdnconfigurationextension which is not a wellknown type inside SfbRpsModule.format.ps1xml
            #so we hack this here so that we order them and select what we need (so we dont return key, datasource)
            $xdsConfigurationOutput = ($xdsConfigurationOutput | select Identity, SupportURL, AllowSdnProviderForBroadcastMeeting, SdnName, SdnLicenseId, SdnAzureSubscriptionId, SdnApiTemplateUrl, SdnApiToken, SdnRuntimeconfiguration, SdnAttendeeFallbackCount)
        }

        return (Sort-GlobalFirst $xdsConfigurationOutput)
    }
}

# output Identity=Global before other identities
function Sort-GlobalFirst($out)
{
    # keep legacy behavior to return nothing instead of $null when nothing is found
    if (($out | measure).Count -eq 0) { return }

    $out | ?{ $_.Identity -eq "Global" }
    $out | ?{ $_.Identity -ne "Global" }
}

# convert PSCustom Object to PSObject by using psserializer
function Custom-ToString($xnode)
{
    $props_to_hide = @("Element","XsAnyElements","XsAnyAttributes")

    $nodes = $xnode.SelectNodes('*[name() = "MS" or name() = "Props"]/*')
    $values = ($nodes | % {
        if ($_.N -notin $props_to_hide)
        {
            $val = $_.SelectSingleNode("text()").Value
            if ($_.Name -eq "B") { $val = [bool]::Parse($val)}
            "$($_.N)=$val"
        }
    })
    if ($values) { [string]::Join(";", $values) }
}

function Convert-PsCustomObjectToPsObject($in)
{
    $serialized = [System.Management.Automation.PSSerializer]::Serialize($in)
    $xml = [xml]$serialized
    foreach ($obj in $xml.GetElementsByTagName("Obj"))
    {
        if ($obj.Item("LST") -eq $null -and $obj.Item("Props") -eq $null)
        {
            $props = $xml.CreateElement("Props", $xml.Objs.xmlns)
            $null = $obj.PrependChild($props)

            if ($obj.Item("ToString") -eq $null)
            {
                $text = Custom-ToString $obj
                if ($text -ne $null)
                {
                    $tostring = $xml.CreateElement("ToString", $xml.Objs.xmlns)
                    $tostring.InnerText = $text
                    $null = $obj.PrependChild($tostring)
                }
            }
        }
    }
    return [System.Management.Automation.PSSerializer]::Deserialize($xml.OuterXml)
}

function Get-FormatsForConfig {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [string]
        # The int status from status record
        ${ConfigType}
    )
    process {
        # order of values like value1 and value2 is important in lines like "ConfigType=value1, value2"
        $mappings = @(
            "ApplicationAccessPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Meeting.ApplicationAccessPolicy",
            "ApplicationMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.PlatformApplications.ApplicationMeetingConfiguration",
            "CallingLineIdentity=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.CallingLineIdentity",
            "DialPlan=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.LocationProfile",
            "ExternalAccessPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.ExternalAccess.ExternalAccessPolicy",
            "InboundBlockedNumberPattern=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundBlockedNumberPattern#Decorated,Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundBlockedNumberPattern",
            "InboundExemptNumberPattern=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundExemptNumberPattern#Decorated,Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundExemptNumberPattern",
            "OnlineAudioConferencingRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineAudioConferencingRoutingPolicy",
            "OnlineDialinConferencingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineDialinConferencing.OnlineDialinConferencingPolicy",
            "OnlineDialinConferencingTenantConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialinConferencingTenantConfiguration",
            "OnlineDialInConferencingTenantSettings=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialInConferencingTenantSettings",
            "OnlineDialInConferencingTenantSettings.AllowedDialOutExternalDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialInConferencingAllowedDomain",
            "OnlineDialOutPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineDialOut.OnlineDialOutPolicy",
            "OnlinePSTNGateway=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AzurePSTNTrunkConfiguration.TrunkConfig#Decorated2,Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AzurePSTNTrunkConfiguration.TrunkConfig",
            "OnlinePstnUsages=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlinePstnUsages",
            "OnlineVoicemailPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineVoicemail.OnlineVoicemailPolicy",
            "OnlineVoiceRoute=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineRoute#Decorated",
            "OnlineVoiceRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineVoiceRoutingPolicy",
            "PrivacyConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.UserServices.PrivacyConfiguration",
            "TeamsAcsFederationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AcsConfiguration.TeamsAcsFederationConfiguration",
            "TeamsAppPermissionPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsAppPermissionPolicy",
            "TeamsAppPermissionPolicy.DefaultCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.DefaultCatalogApp",
            "TeamsAppPermissionPolicy.GlobalCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.GlobalCatalogApp",
            "TeamsAppPermissionPolicy.PrivateCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PrivateCatalogApp",
            "TeamsAppSetupPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsAppSetupPolicy",
            "TeamsAppSetupPolicy.AppPresetList=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.AppPreset",
            "TeamsAppSetupPolicy.AppPresetMeetingList=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.AppPresetMeeting",
            "TeamsAppSetupPolicy.PinnedAppBarApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PinnedApp",
            "TeamsAppSetupPolicy.PinnedMessageBarApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PinnedMessageBarApp",
            "TeamsAudioConferencingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.TeamsAudioConferencing.TeamsAudioConferencingPolicy",
            "TeamsCallHoldPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallHoldPolicy",
            "TeamsCallingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallingPolicy",
            "TeamsCallParkPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallParkPolicy",
            "TeamsChannelsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsChannelsPolicy",
            "TeamsClientConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsClientConfiguration",
            "TeamsComplianceRecordingApplication=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingApplication#Decorated,Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingApplication",
            "TeamsComplianceRecordingApplication.ComplianceRecordingPairedApplications=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingPairedApplication",
            "TeamsComplianceRecordingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsComplianceRecordingPolicy",
            "TeamsComplianceRecordingPolicy.ComplianceRecordingApplications=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingApplication",
            "TeamsCortanaPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCortanaPolicy",
            "TeamsEducationAssignmentsAppPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEducationAssignmentsAppPolicy",
            "TeamsEmergencyCallingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyCallingPolicy",
            "TeamsEmergencyCallRoutingPolicy.EmergencyNumbers=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyNumber",
            "TeamsEmergencyCallRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyCallRoutingPolicy",
            "TeamsFeedbackPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsFeedbackPolicy",
            "TeamsGuestCallingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestCallingConfiguration",
            "TeamsGuestMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestMeetingConfiguration",
            "TeamsGuestMessagingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestMessagingConfiguration",
            "TeamsIPPhonePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsIPPhonePolicy",
            "TeamsMeetingBroadcastConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsMeetingBroadcastConfiguration",
            "TeamsMeetingBroadcastPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMeetingBroadcastPolicy",
            "TeamsMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsMeetingConfiguration.TeamsMeetingConfiguration",
            "TeamsMeetingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Meeting.TeamsMeetingPolicy",
            "TeamsMessagingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMessagingPolicy",
            "TeamsMigrationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsMigrationConfiguration.TeamsMigrationConfiguration",
            "TeamsMobilityPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMobilityPolicy",
            "TeamsNetworkRoamingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsNetworkRoamingPolicy",
            "TeamsNotificationAndFeedsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsNotificationAndFeedsPolicy",
            "TeamsShiftsAppPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsShiftsAppPolicy",
            "TeamsShiftsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsShiftsPolicy",
            "TeamsSurvivableBranchAppliance=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.SurvivableBranchAppliance#Decorated",
            "TeamsSurvivableBranchAppliancePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TeamsBranchSurvivabilityPolicy",
            "TeamsTranslationRule=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AzurePSTNTrunkConfiguration.PstnTranslationRule#Decorated",
            "TeamsTargetingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsTargetingPolicy",
            "TeamsUnassignedNumberTreatment=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.UnassignedNumberTreatmentConfiguration.UnassignedNumberTreatment#Decorated",
            "TeamsUpdateManagementPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsUpdateManagementPolicy",
            "TeamsUpgradeConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsUpgradeConfiguration",
            "TeamsUpgradePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsUpgradePolicy",
            "TeamsVdiPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsVdiPolicy",
            "TeamsVideoInteropServicePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsVideoInteropServicePolicy",
            "TeamsVoiceApplicationsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsVoiceApplicationsPolicy",
            "TeamsWorkLoadPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsWorkLoadPolicy",
            "TenantBlockedCallingNumbers=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TenantBlockedCallingNumbers",
            "TenantBlockedCallingNumbers.InboundBlockedNumberPatterns=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundBlockedNumberPattern",
            "TenantBlockedCallingNumbers.InboundExemptNumberPatterns=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundExemptNumberPattern",
            "TenantDialPlan=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TenantDialPlan",
            "TenantDialPlan.NormalizationRules=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.NormalizationRule",
            "TenantFederationSettings=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.TenantFederationSettings",
            "TenantFederationSettings.AllowedDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.AllowList",
            "TenantFederationSettings.BlockedDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.DomainPattern",
            "TenantLicensingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantConfiguration.TenantLicensingConfiguration",
            "TenantMigrationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantMigration.TenantMigrationConfiguration",
            "TenantNetworkConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.TenantNetworkConfigurationSettings",
            "TenantNetworkConfiguration.NetworkRegions=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.NetworkRegionType#Decorated",
            "TenantNetworkConfiguration.NetworkSites=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkSiteWithExpandParametersType#Decorated",
            "TenantNetworkConfiguration.Subnets=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.SubnetType#Decorated",
            "TenantNetworkRegion=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkRegionType#Decorated",
            "TenantNetworkSite=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkSiteWithExpandParametersType#Decorated",
            "TenantNetworkSubnet=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.SubnetType#Decorated",
            "TenantTrustedIPAddress=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.TrustedIP#Decorated",
            "TeamsFilesPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsFilesPolicy",
            "TeamsEnhancedEncryptionPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEnhancedEncryptionPolicy",
            "TeamsMediaLoggingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMediaLoggingPolicy",
            "TeamsRoomVideoTeleConferencingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsRoomVideoTeleConferencingPolicy",
            "TeamsEventsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEventsPolicy",
            "VideoInteropServiceProvider=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantVideoInteropServiceConfiguration.VideoInteropServiceProvider#Decorated",
            "HostingProvider=Microsoft.Rtc.Management.WritableConfig.Settings.Edge.Hosted.DisplayHostingProviderExtended"
        )

        $mappings | where {$_.StartsWith("$ConfigType")}
    }
}

function Set-FormatOnConfigObject {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        # Object on which typenames need to be set
        ${ConfigObject},

        [Parameter(Mandatory=$true)]
        # Type of configuration
        ${ConfigType}
    )
    process {
        $mappings = Get-FormatsForConfig -ConfigType $ConfigType
        $parenttn = $mappings | where {$_.StartsWith("$ConfigType=")}
        $parenttnList = $parenttn.Split("=")[1].Split(",")
        $childtnmappings = $mappings | where {$_.StartsWith("$ConfigType.")}

        foreach ($inst in $ConfigObject)
        {
            for ($i = 0; $i -lt $parenttnList.Count; $i++)
            {
                $inst.PsObject.TypeNames.Insert($i, $parenttnList[$i])
            }

            foreach($tn in $childtnmappings)
            {
                $childtn = $tn.Split("=")[1]
                $childPropName = $tn.Split("=")[0].Split(".")[1]
                foreach($instc in $inst.$childPropName)
                {
                    $instc.PsObject.TypeNames.Insert(0,$childtn)
                }
            }
        }

        return $ConfigObject
    }
}

function Set-FixToStringOnAllowedDomains($in, $val)
{
    $serialized = [System.Management.Automation.PSSerializer]::Serialize($in)
    $xml = [xml]$serialized
    foreach ($obj in $xml.GetElementsByTagName("Obj"))
    {
        if ($obj.Attributes["N"].'#text' -eq 'AllowedDomains')
        {
            if ($obj.Item("ToString") -ne $null)
            {
                $obj.Item("ToString").'#text' = $val
            }
        }
    }
    return [System.Management.Automation.PSSerializer]::Deserialize($xml.OuterXml)
}

function Set-FixTenantFedConfigObject {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        # Object for Get-CsTenantFederationConfiguration
        ${ConfigObject}
    )
    process {
        if($ConfigObject.AllowedDomains.AllowedDomain -eq $null)
		{
			$ConfigObject.AllowedDomains = New-CsEdgeAllowAllKnownDomains -MsftInternalProcessingMode TryModern
		}
		elseif($ConfigObject.AllowedDomains.AllowedDomain.Count -eq 0)
		{
			$ConfigObject = Set-FixToStringOnAllowedDomains -val "" -in  $ConfigObject
		}
		elseif($ConfigObject.AllowedDomains.AllowedDomain.Count -gt 0)
		{
			$str = "Domain=" + [string]::join(",Domain=",$ConfigObject.AllowedDomains.AllowedDomain.Domain)
			$ConfigObject = Set-FixToStringOnAllowedDomains -val $str -in  $ConfigObject
		}

		return $ConfigObject
    }
}

#Add proerty OutboundTeamsNumberTranslationRules into the response object
function Set-FixTypoInOnlinePSTNGatewayConfigObject {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        # Object for Get-CsOnlinePSTNGateway
        ${ConfigObject}
    )
    process {
        foreach ($inst in $ConfigObject)
        {
			$inst | Add-Member NoteProperty 'OutboundTeamsNumberTranslationRules' $inst.OutbundTeamsNumberTranslationRules
		}

		return $ConfigObject
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolicyRankings from user's input from string[] to object[]

function Grant-CsGroupPolicyPackageAssignment {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $GroupId,

        [Parameter(Mandatory=$false, position=1)]
        [AllowNull()]
        [AllowEmptyString()]
        $PackageName,

        [Parameter(position=2)]
        [System.String[]]
        $PolicyRankings
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalRankingList = @()
            foreach ($PolicyTypeAndRank in $PolicyRankings)
            {
                $PolicyTypeAndRankArray = $PolicyTypeAndRank -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndRankArray = $PolicyTypeAndRankArray.Trim()
                if ($PolicyTypeAndRankArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Rank pair: $PolicyTypeAndRank. Please use a proper delimeter"
                }
                $PolicyTypeAndRankObject = [psobject]@{
                    PolicyType = $PolicyTypeAndRankArray[0]
                    Rank = $PolicyTypeAndRankArray[1] -as [int]
                }
                $InternalRankingList += $PolicyTypeAndRankObject
            }
            $null = $PSBoundParameters.Remove("PolicyRankings")
            $null = $PSBoundParameters.Add("PolicyRankings", $InternalRankingList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsGroupPolicyPackageAssignment @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Grant-CsTeamsPolicy with Grant-CsUserPolicy, Grant-CsTenantPolicy, and Group grant

function Grant-CsTeamsPolicy {
    [CmdletBinding(PositionalBinding=$true, DefaultParameterSetName="Identity", SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    param(
        [ArgumentCompleter({param ($CommandName, $ParameterName, $WordToComplete, $CommandAst, $FakeBoundParameters) return @("ApplicationAccessPolicy","BroadcastMeetingPolicy","CallingLineIdentity","ClientPolicy","CloudMeetingPolicy","ConferencingPolicy","DialoutPolicy","ExternalAccessPolicy","ExternalUserCommunicationPolicy","GraphPolicy","GroupPolicyPackageAssignment","HostedVoicemailPolicy","IPPhonePolicy","MobilityPolicy","OnlineAudioConferencingRoutingPolicy","OnlineVoicemailPolicy","OnlineVoiceRoutingPolicy","Policy","TeamsAppPermissionPolicy","TeamsAppSetupPolicy","TeamsAudioConferencingPolicy","TeamsCallHoldPolicy","TeamsCallingPolicy","TeamsCallParkPolicy","TeamsChannelsPolicy","TeamsComplianceRecordingPolicy","TeamsCortanaPolicy","TeamsEmergencyCallingPolicy","TeamsEmergencyCallRoutingPolicy","TeamsEnhancedEncryptionPolicy","TeamsFeedbackPolicy","TeamsFilesPolicy","TeamsIPPhonePolicy","TeamsMeetingBroadcastPolicy","TeamsMeetingPolicy","TeamsMessagingPolicy","TeamsMobilityPolicy","TeamsShiftsPolicy","TeamsSurvivableBranchAppliancePolicy","TeamsUpdateManagementPolicy","TeamsUpgradePolicy","TeamsVdiPolicy","TeamsVerticalPackagePolicy","TeamsVideoInteropServicePolicy","TeamsWorkLoadPolicy","TenantDialPlan","UserOrTenantPolicy","UserPolicyPackage","VoiceRoutingPolicy") | ?{ $_ -like "$WordToComplete*" } })]
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of the policy
        ${PolicyType},

        [Parameter(Mandatory=$false, Position=1)]
        [System.String]
        # Name of the policy instance
        ${PolicyName},

        # Mandatory=$false allows for deprecated "identity=$null means Grant-to-tenant" behavior
        # eventually we should set Mandatory=$true and require preferred -Global switch for that
        [Parameter(Mandatory=$false, Position=0, ParameterSetName="Identity", ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$true, Position=0, ParameterSetName="GrantToTenant")]
        [Switch]
        # Use global indicating grant to tenant
        ${Global},

        [Parameter(Mandatory=$true, Position=0, ParameterSetName="GrantToGroup")]
        [ValidateNotNullOrEmpty()]
        [System.String]
        # Unique identifier for the group
        ${Group},
        
        [Parameter(Mandatory=$false, ParameterSetName="GrantToGroup")]
        [Nullable[int]]
        ${Rank},

        [Parameter(Mandatory=$false)]
        ${AdditionalParameters}
    )

    process {
        if (-not $PSBoundParameters.ContainsKey("PolicyName"))
        {
            # this parameter should be Mandatory=$true, however the [AllowNull]/[AllowEmptyString] attributes don't get surfaced to the wrapper cmdlet that is generated
            throw [System.Management.Automation.ParameterBindingException]::new("Cannot process command because of one or more missing mandatory parameters: PolicyName.")
        }

        if ($PsCmdlet.ParameterSetName -eq "GrantToGroup")
        {
            $parameters = @{
                GroupId=$Group
                PolicyType=$PolicyType
                PolicyName=$PolicyName
            }
            if ($Rank) { $parameters["Rank"] = $Rank }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsGroupPolicyAssignment @parameters
        }
        elseif ([string]::IsNullOrWhiteSpace($Identity))
        {
            if (-not $Global)
            {
                # The only way to grant to tenant is to use -Global
                throw [System.Management.Automation.ParameterBindingException]::new("Cannot process command because of one or more missing mandatory parameters: Global.")
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsTenantPolicy -PolicyType $PolicyType -PolicyName $PolicyName -AdditionalParameters $AdditionalParameters
            }
        }
        else
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsUserPolicy -Identity $Identity -PolicyType $PolicyType -PolicyName $PolicyName -AdditionalParameters $AdditionalParameters
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function New-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true)]
        [System.Collections.Hashtable]
        ${PropertyBag}
    )

    process {
        #Todo: validate that $PropertyBag contains Identity or just depend on the service to reject otherwise
        $xdsConfigurationOutput = $null

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsConfiguration -ConfigType $ConfigType -Body $PropertyBag -ErrorVariable err
        if ($err) { return }

        #Todo - Handle where new failed - because the identity already exists, rbac or someother server error
        #Todo: Ensure to test this under TPM, given we are referring the Microsoft.Teams.ConfigAPI.Cmdlets module
        $xdsConfigurationOutput = Get-CsConfigurationModern -ConfigType $ConfigType -Identity $PropertyBag['Identity']

        $xdsConfigurationOutput
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the identity

function Remove-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration deleted.
        ${ConfigType},

		[Parameter(Mandatory=$true)]
        [System.String]
        # Name of configuration deleted.
        ${Identity}
    )

    process {
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsConfiguration -ConfigType $ConfigType -ConfigName $Identity
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Set-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true)]
        [System.Collections.Hashtable]
        ${PropertyBag}
    )

    process {
        
        if(!($PropertyBag.ContainsKey('Identity')))
        {
            $PropertyBag['Identity'] =  "Global"
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsConfiguration -ConfigType $ConfigType -ConfigName $PropertyBag['Identity'] -Body $PropertyBag
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Clear-CsOnlineTelephoneNumberOrder {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # OrderId of the Search Order
        ${OrderId}
    )

    process {

        $null = $PSBoundParameters.Add("Action", "Cancel")
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Complete-CsOnlineTelephoneNumberOrder @PSBoundParameters -ErrorAction Stop

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Complete-CsOnlineTelephoneNumberOrder {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # OrderId of the Search Order
        ${OrderId}
    )

    process {

        $null = $PSBoundParameters.Add("Action", "Complete")
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Complete-CsOnlineTelephoneNumberOrder @PSBoundParameters -ErrorAction Stop

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsOnlineTelephoneNumberModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # Telephone numbers to remove
        ${TelephoneNumber}
    )

    process {

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineTelephoneNumberPrivate -TelephoneNumber $TelephoneNumber

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsPhoneNumberAssignment {
    [CmdletBinding(DefaultParameterSetName="RemoveSome")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [Parameter(Mandatory=$true, ParameterSetName='RemoveAll')]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [System.String]
        ${PhoneNumber},
        
        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [System.String]
        ${PhoneNumberType},
        
        [Parameter(Mandatory=$true, ParameterSetName='RemoveAll')]
        [Switch]
        ${RemoveAll}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsPhoneNumberAssignment @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsPhoneNumberAssignment {
    [CmdletBinding(DefaultParameterSetName="Assignment")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [Parameter(Mandatory=$true, ParameterSetName='Attribute')]
        [System.String]
        ${Identity},
        
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [System.String]
        ${PhoneNumber},
        
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [System.String]
        ${PhoneNumberType},
        
        [Parameter(Mandatory=$false, ParameterSetName='Assignment')]
        [System.String]
        ${LocationId},
        
        [Parameter(Mandatory=$true, ParameterSetName='Attribute')]
        [System.Boolean]
        ${EnterpriseVoiceEnabled}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsPhoneNumberAssignment @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Write diagnostic message back to console

function Get-CsBusinessVoiceDirectoryDiagnosticData {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Category('Path')]
        [System.String]
        # PartitionKey of the table.
        ${PartitionKey},

        [Parameter(Mandatory)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Category('Path')]
        [System.String]
        # Region to query Bvd table.
        ${Region},

        [Parameter(Mandatory)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Category('Path')]
        [System.String]
        # Bvd table name.
        ${Table},

        [Parameter()]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Category('Query')]
        [System.Int32]
        # Optional resultSize.
        ${ResultSize},

        [Parameter()]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Category('Query')]
        [System.String]
        # Optional row key.
        ${RowKey}
    )

    process {
        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsBusinessVoiceDirectoryDiagnosticData @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        $output = @()
        foreach($internalProperty in $internalOutput.Property)
        {
            $entityProperty = [Microsoft.Rtc.Management.Hosted.Group.Models.EntityProperty]::new()
            $entityProperty.ParseFrom($internalProperty)
            $output += $entityProperty
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------
# Objective of this custom file: Integrate Get-CsOnlineDialinConferencingUser with Get-CsOdcUser and Search-CsOdcUser
function Get-CsOdcUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOdcUser -Identity $Identity
        }
        else
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsOdcUser -Top $ResultSize
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------
# Objective of this custom file: Integrate Get-CsOnlineDialinConferencingUser with Get-CsOdcUser
function Get-CsOdcUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOdcUser -Identity $Identity
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Register-CsOdcServiceNumber

function Register-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false, DefaultParameterSetName="ById")]
    param(

    [string]
    [ValidateNotNullOrEmpty()]
    [Parameter(Mandatory=$true, ParameterSetName="ById", Position=0)]
    ${Identity},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [ValidateNotNull()]
    [Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="ByInstance")]
    ${Instance},

    [string]
    [ValidateNotNull()]
    ${BridgeId},

    [string]
    [ValidateNotNullOrEmpty()]
    ${BridgeName},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force})

    process {
        
        if ($Identity -ne "")
        {
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Register-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null)
        {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]::new()
            $Body.Number = $Instance.Number
            $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            $Body.SecondaryLanguages = $Instance.SecondaryLanguages

            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Register-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Unregister-CsOdcServiceNumber

function Unregister-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false, DefaultParameterSetName="ById")]
    param(

    [string]
    [ValidateNotNullOrEmpty()]
    [Parameter(Mandatory=$true, ParameterSetName="ById", Position=0)]
    ${Identity},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [ValidateNotNull()]
    [Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="ByInstance")]
    ${Instance},

    [string]
    [ValidateNotNull()]
    ${BridgeId},

    [string]
    [ValidateNotNullOrEmpty()]
    ${BridgeName},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [switch]
    ${RemoveDefaultServiceNumber})

    process {
        if ($Identity -ne "") 
        {
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null)
        {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]::new()
            $Body.Number = $Instance.Number
            $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            $Body.SecondaryLanguages = $Instance.SecondaryLanguages

            if($PSBoundParameters.ContainsKey('RemoveDefaultServiceNumber') -eq $false)
            {
                $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName
            }
            else
            {
                $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName -RemoveDefaultServiceNumber
            }
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: cmdlet for Orchestration- This cmdlets compress csv files.

function New-CsBatchTeamsDeployment 
{
    [OutputType([System.String])]
    [CmdletBinding( PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        $TeamsFilePath,

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        $UsersFilePath,

        [Parameter(Mandatory=$true, position=2)]
        [System.String]
        $UsersToNotify
    )

    process {
        try 
        {
           $TeamsFile =  "$env:TEMP\Teams.csv"
           $UsersFile =  "$env:TEMP\Users.csv"
           Copy-Item $TeamsFilePath -Destination $TeamsFile -Force
           Copy-Item $UsersFilePath -Destination $UsersFile -Force
           $zipFile = "$env:TEMP\TeamsDeployment.Zip"

           $compress = @{
           LiteralPath= $TeamsFile , $UsersFile
           CompressionLevel = "Fastest"
           DestinationPath = $zipFile
           }

           Compress-Archive @compress -Update

           $FileStream = [System.IO.File]::ReadAllBytes($zipFile)
           $B64String = [System.Convert]::ToBase64String($FileStream, [System.Base64FormattingOptions]::None)

           $null = $PSBoundParameters.Remove("TeamsFilePath")
           $null = $PSBoundParameters.Remove("UsersFilePath")
           $null = $PSBoundParameters.Add("DeploymentCsv", $B64String) 

           $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsBatchTeamsDeployment @PSBoundParameters

           Write-Output $internalOutput 
                                            
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

<#
.Synopsis
Get meeting migration transaction history for a user
.Description
Get meeting migration transaction history for a user
#>
function Get-CsMeetingMigrationTransactionHistory {
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Identity.
        # Supports UPN and SIP
        ${Identity},

        [Parameter()]
        [System.String]
        # CorrelationId
        ${CorrelationId},

        [Parameter()]
        [System.DateTime]
        # start time filter - to get meeting migration transaction history after starttime
        ${StartTime},

        [Parameter()]
        [System.DateTime]
        # end time filter - to get meeting migration transaction history before endtime
        ${EndTime}
    )

    process {
        try {
            # Fetching only Meeting Migration transaction history
            # need to pipe to convert-ToJson | Convert-FromJson to support output in list format and sending down to further pipeline commands.
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationTransactionHistoryModern -userIdentity $Identity -StartTime $StartTime -EndTime $EndTime -CorrelationId $CorrelationId | Foreach-Object  { ( ConvertTo-Json $_) } | Foreach-Object {ConvertFrom-Json $_} 
        } 
        catch 
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

<#
.Synopsis
Get meeting migration status for a user or at tenant level
.Description
Get meeting migration status for a user or tenant level
#>
function Get-CsMmsStatus {
    param(
        [Parameter()]
        [System.String]
        # end time filter - to get meeting migration status before endtime
        ${EndTime},

        [Parameter()]
        [System.String]
        # Identity.
        # Supports UPN and SIP, domainName LogonName
        ${Identity},

        [Parameter()]
        [System.String]
        # Meeting migration type - SfbToSfb, SfbToTeams, TeamsToTeams, AllToTeams, ToSameType, Unknown
        ${MigrationType},

        [Parameter()]
        [System.String]
        # start time filter - to get meeting migration status after starttime
        ${StartTime},

        [Parameter()]
        [switch]
        # SummaryOnly - to get only meting migration status summary.
        ${SummaryOnly},

        [Parameter()]
        [System.String]
        # state of meeting Migration status - Pending, InProgress, Failed, Succeeded
        ${State}   
    )

    process {
        try {
            if($PSBoundParameters.ContainsKey('SummaryOnly')) 
            {
                # Fetching only Meeting Migration status summary
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationStatusSummaryModern -Identity $Identity -StartTime $StartTime -EndTime $EndTime -State $state -MigrationType $MigrationType | ConvertTo-Json
            }
            else 
            {
                # Need to display output in a list format and should be able to pipe output to other cmdlets for filtering.
                # with Format-List, not able to send the output for piping. So did this Convert-ToJson and Converting object from Json which displays output in list format and also able to refer with index value.
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationStatusModern -Identity $Identity -StartTime $StartTime -EndTime $EndTime -State $state -MigrationType $MigrationType |  Foreach-Object  { ( ConvertTo-Json $_) } | Foreach-Object {ConvertFrom-Json $_}
            }
        } 
        catch 
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function Get-CsTeamTemplateList {
    [OutputType([Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ITeamTemplateSummary], [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IErrorObject])]
    [CmdletBinding(DefaultParameterSetName='DefaultLocaleOverride', PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The language and country code of templates localization.
        ${PublicTemplateLocale}
    )

    process {
        if ([string]::IsNullOrWhiteSpace($PublicTemplateLocale)) {
            $null = $PSBoundParameters.Add("PublicTemplateLocale", "en-US")
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsTeamTemplateList @PSBoundParameters
    }
}
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsTenant with Get-CsTenantObou

function Get-CsTenantPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param()

    process {
        $defaultPropertySet = "Extended"
        $tenant = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsTenantObou -DefaultPropertySet $defaultPropertySet
        $allProperties = $tenant | Select-Object -Property * -ExcludeProperty LastProvisionTimeStamps, LastPublishTimeStamps 
        $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $tenant.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $tenant.LastPublishTimeStamps.AdditionalProperties 

        Write-Output $allProperties
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: map parameters to request body

function Set-CsOnlineSipDomainModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Domain Name parameter.
        ${Domain},

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        # Action decides enable or disable sip domain
        ${Action}
    )

    process {

        $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.TenantSipDomainRequest]::new()

        $Body.DomainName = $Domain
        $Body.Action = $Action

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineSipDomain -Body $Body
        Write-AdminServiceDiagnostic($result.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser and Search-CsUser

function Get-CsUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To not display user policies in output
        ${SkipUserPolicies},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch soft-deleted users
        ${SoftDeletedUsers},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.AccountType]
        # To only fetch users with specified account type
        ${AccountType}
    )

    process {
        $defaultPropertySet = "Extended"
        $internalfilter = ""
        if ($AccountType)
        {
            if (![string]::IsNullOrWhiteSpace($Identity))
            {
                Write-Error "AccountType parameter cannot be used with Identity parameter."
                return
            }
            else
            {
                $internalfilter = "AccountType -eq '$AccountType'"
            }
        }
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet
            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
        else
        {
            if ($SoftDeletedUsers)
            {
                if (![string]::IsNullOrWhiteSpace($internalfilter))
                {
                    Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $internalfilter -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet -Softdeleteduser:$true | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
                }
                else
                {
                    Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet -Softdeleteduser:$true | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
                }
            }
            else
            {
                if (![string]::IsNullOrWhiteSpace($internalfilter))
                {
                    Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $internalfilter -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
                }
                else
                {
                    Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
                }            
            }
        }
    }
}
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser

function Get-CsUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To not display user policies in output
        ${SkipUserPolicies}
    )

    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet "Extended"

            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser and Search-CsUser

function Get-CsUserSearch {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, DontShow = $true)]
        [System.String[]]
        # List of user identifiers
        ${Identities},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Filter to be applied to the list of users
        ${Filter},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To skip user policies in output
        ${SkipUserPolicies},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch soft-deleted users
        ${SoftDeletedUsers},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.AccountType]
        # To only fetch users with specified account type
        ${AccountType}
    )

    process {
        $defaultPropertySet = "Extended"
        if ($AccountType)
        {
            if (![string]::IsNullOrWhiteSpace($Identity))
            {
                Write-Error "AccountType parameter cannot be used with Identity parameter."
                return
            }
            if (![string]::IsNullOrWhiteSpace($Filter))
            {
                $Filter += " -and AccountType -eq '$AccountType'"
            }
            else
            {
                $Filter = "AccountType -eq '$AccountType'"
            }
        }
        if ($Identities -ne $null)
        {
            if (![string]::IsNullOrWhiteSpace($Filter))
            {
                Write-Error "Filter parameter cannot be used along with Identity input."
                return
            }
            $i = 0
            $count = $Identities.Count
            $filterstring = ""
            while ($i -lt $count)
            {
                $id = $Identities[$i]
                if (![string]::IsNullOrWhiteSpace($filterstring))
                {
                    $filterstring += " or userprincipalname eq '$id'"
                }
                else
                {
                    $filterstring = "userprincipalname eq '$id'"
                }
                $i = $i + 1
            }
            
            if (![string]::IsNullOrEmpty($filterstring))
            {
                $users = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $filterstring  | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
            }    
            Write-Output $users
        }
        
        elseif (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet
            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
        elseif (![string]::IsNullOrWhiteSpace($Filter))
        {
            if ($SoftDeletedUsers)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $Filter -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet -Softdeleteduser:$true | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $Filter -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
            }
        }
        else 
        {
            if ($SoftDeletedUsers)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet -Softdeleteduser:$true | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
            }
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineVoiceUser with Get-CsUser 

function Get-CsVoiceUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.Management.Automation.SwitchParameter]
        #To fetch location field
        ${ExpandLocation},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${First},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch users which have a number assigned to them
        ${NumberAssigned},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch users which don't have a number assigned to them
        ${NumberNotAssigned},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Guid]]
        # LocationId of users to be returned
        ${LocationId},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Guid]]
        # CivicAddressId of users to be returned
        ${CivicAddressId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.PSTNConnectivity]
        # PSTNConnectivity of the users to be returned
        ${PSTNConnectivity},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.EnterpriseVoiceStatus]
        # EnterpriseVoiceStatus of the users to be returned
        ${EnterpriseVoiceStatus}
    )
    process 
    {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
        else
        {
            if($NumberAssigned -and $NumberNotAssigned)
            {
                Write-Error "You can only pass either NumberAssigned or NumberNotAssigned at a time."
                return
            }

            if (($LocationId -and !$CivicAddressId) -or ($CivicAddressId -and !$LocationId))
            {
                Write-Error "LocationId and CivicAddressId must be provided together."
                return
            }    

            $filters = @()   #array of individual filters
            $addNumberInSelectProperties = $false
            if ($LocationId -and $CivicAddressId)
            {
                $filters += "Number/LocationId eq '$LocationId' and Number/CivicAddressId eq '$CivicAddressId'"
                $addNumberInSelectProperties = $true
            }
                
            if ($PSTNConnectivity)
            {
                if ($PSTNConnectivity -eq 'OnPremises' -or $PSTNConnectivity -eq 'Online')
                {
                    $filters += "PSTNConnectivity eq '$PSTNConnectivity'"
                }
            }

            if ($EnterpriseVoiceStatus)
            {
                if ($EnterpriseVoiceStatus -eq 'Enabled')
                {
                    $filters += "EnterpriseVoiceEnabled eq true"
                }
                elseif ($EnterpriseVoiceStatus -eq 'Disabled')
                {
                    $filters += "EnterpriseVoiceEnabled eq false"
                }
            }

            if ($NumberAssigned)
            {
                $filters += "LineUri ne '$null'"
            }
            elseif ($NumberNotAssigned)
            {
                $filters += "LineUri eq '$null'"
            }

            $filterstring = $filters -join " and "
            $selectProperties = "Objectid,EnterpriseVoiceEnabled,DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain"

            if ($addNumberInSelectProperties -eq $true)
            {
                $selectProperties += ",Number"
            }
            
            if($ExpandLocation)
            {
                $selectProperties += ",Location"
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true -Select $selectProperties -Filter $filterstring -Top $First | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true -Select $selectProperties -Filter $filterstring -Top $First | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineVoiceUser with Get-CsUser 

function Get-CsVoiceUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [switch]
        #To fetch location field
        ${ExpandLocation}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
    }
}
function Set-CsOnlineVoiceUserV2 {
[CmdletBinding(DefaultParameterSetName='Id', SupportsShouldProcess)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${TelephoneNumber},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${LocationId}
    )
    process {
        try {
            $Body = @{
                TelephoneNumber=$TelephoneNumber
                LocationId=$LocationId
            }
            $Payload = @{
                UserId = $Identity
                Body = $Body
            }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserGenerated @Payload
        }
        catch
        {
            throw
        }
    }
}
function Set-CsUserModern {
[CmdletBinding(DefaultParameterSetName='Id')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$false)]
        ${EnterpriseVoiceEnabled},
 
        [Parameter(Mandatory=$false)]
        ${HostedVoiceMail},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${LineURI},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${OnPremLineURI}
    ) 

    process {

        try {
            $PhoneNumber = $LineURI
            if ($PSBoundParameters.ContainsKey('OnPremLineURI')) {
                Write-Warning -Message "OnPremLineURI will be deprecated. Please use LineURI to update user's phone number."
                if (!$PSBoundParameters.ContainsKey('LineURI')){
                    $PhoneNumber = $OnPremLineURI
                }
                else{
                    Write-Error "Please specify either one parameter OnPremLineURI or LineURI to assign phone number."
                    return
                }
            }

            $Body = @{
                EnterpriseVoiceEnabled=$EnterpriseVoiceEnabled
                HostedVoiceMail=$HostedVoiceMail
            }

            if ($PSBoundParameters.ContainsKey('LineURI') -or $PSBoundParameters.ContainsKey('OnPremLineURI')) {
                $Body.LineUri = $PhoneNumber
            }

            $Payload = @{
                UserId = $Identity
                Body = $Body
            }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserGenerated @Payload
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function New-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]
        ${MakeCalls},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]     
        ${ManageSettings},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]
        ${ReceiveCalls}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]
        ${MakeCalls},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]     
        ${ManageSettings},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]
        ${ReceiveCalls}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsUserCallingSettings {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [Parameter(Mandatory=$true, ParameterSetName='ForwardingOnOff')]
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]
	    [Parameter(Mandatory=$true, ParameterSetName='UnansweredOnOff')]
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupMembership')]
	    [Parameter(Mandatory=$true, ParameterSetName='CallGroupNotification')]
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [Parameter(Mandatory=$true, ParameterSetName='ForwardingOnOff')]
        [System.Boolean]
        ${IsForwardingEnabled},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [ValidateSet('Immediate','Simultaneous')]
        [System.String]
        ${ForwardingType},
        
        [Parameter(Mandatory=$false, ParameterSetName='Forwarding')]
        [System.String]     
        [AllowNull()]
        ${ForwardingTarget},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [ValidateSet('SingleTarget','Voicemail','MyDelegates','Group')]
        [System.String]
        ${ForwardingTargetType},
		
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]
	    [Parameter(Mandatory=$true, ParameterSetName='UnansweredOnOff')]
        [System.Boolean]
        ${IsUnansweredEnabled},
        
        [Parameter(Mandatory=$false, ParameterSetName='Unanswered')]
        [System.String]    
        [AllowNull()]
        ${UnansweredTarget},
        
        [Parameter(Mandatory=$false, ParameterSetName='Unanswered')]
	    [ValidateSet("", "SingleTarget","Voicemail","MyDelegates","Group")]
        [System.String]
        ${UnansweredTargetType},
		
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]	    
        [System.String]    
        [AllowNull()]
        ${UnansweredDelay},
		
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
		[ValidateSet('Simultaneous','InOrder')]
        [System.String]
        ${CallGroupOrder},
        
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
        [System.Array]
        [AllowNull()]
        [AllowEmptyCollection()]
        ${CallGroupTargets},
        
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupMembership')]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ICallGroupMembershipDetails[]]
        [AllowEmptyCollection()]
        ${GroupMembershipDetails},
		
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupNotification')]
	    [ValidateSet('Ring','Mute','Banner')]
        [System.String]
        ${GroupNotificationOverride}
    )

    process {
            if ($PSBoundParameters.ContainsKey('UnansweredDelay'))
              {
                if(($UnansweredDelay -as  [TimeSpan]) -and ($UnansweredDelay -le (New-TimeSpan -Hours 0 -Minutes 1 -Seconds 0)) -and ($UnansweredDelay -ge (New-TimeSpan -Hours 0 -Minutes 0 -Seconds 0)))            
                {
                    $UnansweredDelay = $UnansweredDelay
                }
                else
                {
                    write-warning "Unanswered delay is not in correct time range"
                    return
                }
            }

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserCallingSettings @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function New-CsCustomPolicyPackage {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $Identity,

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        $PolicyList,

        [Parameter(position=2)]
        $Description
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalPolicyList = @()
            foreach ($PolicyTypeAndName in $PolicyList)
            {
                $PolicyTypeAndNameArray = $PolicyTypeAndName -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndNameArray = $PolicyTypeAndNameArray.Trim()
                if ($PolicyTypeAndNameArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Name pair: $PolicyTypeAndName. Please use a proper delimeter"
                }
                $PolicyTypeAndNameObject = [psobject]@{
                    PolicyType = $PolicyTypeAndNameArray[0]
                    PolicyName = $PolicyTypeAndNameArray[1]
                }
                $InternalPolicyList += $PolicyTypeAndNameObject
            }
            $null = $PSBoundParameters.Remove("PolicyList")
            $null = $PSBoundParameters.Add("PolicyList", $InternalPolicyList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsCustomPolicyPackage @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function Update-CsCustomPolicyPackage {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $Identity,

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        $PolicyList,

        [Parameter(position=2)]
        $Description
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalPolicyList = @()
            foreach ($PolicyTypeAndName in $PolicyList)
            {
                $PolicyTypeAndNameArray = $PolicyTypeAndName -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndNameArray = $PolicyTypeAndNameArray.Trim()
                if ($PolicyTypeAndNameArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Name pair: $PolicyTypeAndName. Please use a proper delimeter"
                }
                $PolicyTypeAndNameObject = [psobject]@{
                    PolicyType = $PolicyTypeAndNameArray[0]
                    PolicyName = $PolicyTypeAndNameArray[1]
                }
                $InternalPolicyList += $PolicyTypeAndNameObject
            }
            $null = $PSBoundParameters.Remove("PolicyList")
            $null = $PSBoundParameters.Add("PolicyList", $InternalPolicyList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Update-CsCustomPolicyPackage @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Export-CsAutoAttendantHolidays {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be exported..
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Use ResponseType 1 as binary output
        $PSBoundParameters.Add("ResponseType", 1)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $internalOutput.ExportHolidayResultSerializedHolidayRecord
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Export-CsOnlineAudioFile

function Export-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId}
    )

    process {
        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }

        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $base64content = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Export-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($base64content -eq $null) {
            return $null
        }

        $output = [System.Convert]::FromBase64CharArray($base64content, 0, $base64content.Length)
        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Write diagnostic message back to console

function Find-CsGroup {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The SearchQuery parameter defines a search query to search the display name or the sip address or the GUID of groups.
        ${SearchQuery},

        [Parameter(Mandatory=$false, position=1)]
        [System.Nullable[System.UInt32]]
        # The MaxResults parameter identifies the maximum number of results to return.
        ${MaxResults},

        [Parameter(Mandatory=$false, position=2)]
        [System.Boolean]
        # The ExactMatchOnly parameter instructs the cmdlet to return exact matches only.
        ${ExactMatchOnly},

        [Parameter(Mandatory=$false, position=3)]
        [System.Boolean]
        # The MailEnabledOnly parameter instructs the cmdlet to return mail enabled only.
        ${MailEnabledOnly},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Find-CsGroup @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalGroup in $internalOutput.Group)
        {
            $group = [Microsoft.Rtc.Management.Hosted.Group.Models.GroupModel]::new()
            $group.ParseFrom($internalGroup)
            $output += $group
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Put nested ApplicationInstance object as first layer object

function Find-CsOnlineApplicationInstance {
    [OutputType([Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ApplicationInstance])]
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # A query for application instances by display name, telephone number, or GUID of the application instance
        ${SearchQuery},

        [Parameter(Mandatory=$false, position=1)]
        [System.Nullable[System.UInt32]]
        # The maximum number of results to return
        ${MaxResults},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # Instruct the cmdlet to return exact matches only
        ${ExactMatchOnly},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # Instruct the cmdlet to return only application instances that are associated to a configuration
        ${AssociatedOnly},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        # instructs the cmdlet to return only application instances that are not associated to any configuration
        ${UnAssociatedOnly},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Find-CsOnlineApplicationInstance @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalOutputApplicationInstance in $internalOutput.ApplicationInstance)
        {
            $applicationInstance = [Microsoft.Rtc.Management.Hosted.Online.Models.FindApplicationInstanceResult]::new()
            $applicationInstance.ParseFrom($internalOutputApplicationInstance)
            $output += $applicationInstance
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsAutoAttendant {
    [CmdletBinding(DefaultParameterSetName='GetAllParamSet', PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0, ParameterSetName='GetSpecificParamSet')]
        [System.String]
        # The identity for the AA to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, the status records for each auto attendant in the result set are also retrieved.
        ${IncludeStatus},

        [Parameter(Mandatory=$false, position=2, ParameterSetName='GetAllParamSet')]
        [Int]
        # The First parameter indicates the maximum number of auto attendants to retrieve as the result.
        ${First},

        [Parameter(Mandatory=$false, position=3, ParameterSetName='GetAllParamSet')]
        [Int]
        # The Skip parameter indicates the number of initial auto attendants to skip in the result.
        ${Skip},

        [Parameter(Mandatory=$false, position=4, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, only auto attendants' names, identities and associated application instances will be retrieved.
        ${ExcludeContent},

        [Parameter(Mandatory=$false, position=5, ParameterSetName='GetAllParamSet')]
        [System.String]
        # If specified, only auto attendants whose names match that value would be returned.
        ${NameFilter},

        [Parameter(Mandatory=$false, position=6, ParameterSetName='GetAllParamSet')]
        [System.String]
        # If specified, the retrieved auto attendants would be sorted by the specified property.
        ${SortBy},

        [Parameter(Mandatory=$false, position=7, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, the retrieved auto attendants would be sorted in descending order.
        ${Descending},

        [Parameter(Mandatory=$false, position=8)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Identity")
        $null = $PSBoundCommonParameters.Remove("First")
        $null = $PSBoundCommonParameters.Remove("Skip")
        $null = $PSBoundCommonParameters.Remove("ExcludeContent")
        $null = $PSBoundCommonParameters.Remove("NameFilter")
        $null = $PSBoundCommonParameters.Remove("SortBy")
        $null = $PSBoundCommonParameters.Remove("Descending")

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalOutputAutoAttendant in $internalOutput.AutoAttendant)
        {
            $autoAttendant = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
            $autoAttendant.ParseFrom($internalOutputAutoAttendant, $ExcludeContent)

            if ($Identity)
            {
                # Append common parameter here
                $getCsAutoAttendantStatusParameters = @{Identity = $autoAttendant.Identity}
                foreach($p in $PSBoundCommonParameters.GetEnumerator())
                {
                    $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
                }

                $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters

                $autoAttendant.AmendStatus($internalStatus)
            }

            $output += $autoAttendant
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantHolidays {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be exported..
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String[]]
        # The identity for the AA to be retrieved.
        ${Years},

        [Parameter(Mandatory=$false, position=2)]
        [System.String[]]
        # If specified, the status records for each auto attendant in the result set are also retrieved.
        ${Names},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        if ($PSBoundParameters.ContainsKey("Years")) {
            $null = $PSBoundParameters.Remove("Years")
            $PSBoundParameters.Add("Year", $Years)
        }

        if ($PSBoundParameters.ContainsKey("Names")) {
            $null = $PSBoundParameters.Remove("Names")
            $PSBoundParameters.Add("Name", $Names)
        }

        # Use ResponseType 0 as visualization record
        $PSBoundParameters.Add("ResponseType", 0)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalHolidayVisualizationRecord in $internalOutput.HolidayVisualizationRecord)
        {
            $holidayVisualizationRecord = [Microsoft.Rtc.Management.Hosted.OAA.Models.HolidayVisRecord]::new()
            $holidayVisualizationRecord.ParseFrom($internalHolidayVisualizationRecord)
            $output += $holidayVisualizationRecord
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsAutoAttendantStatus {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String[]]
        ${IncludeResources},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.StatusRecord]::new()
        $output.ParseFrom($internalOutput)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantSupportedLanguage {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter designates a specific language to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Use ResponseType 1 as binary output
        if ($PSBoundParameters.ContainsKey('Identity')) {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantSupportedLanguage @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Language]::new()
            $output.ParseFrom($internalOutput)

            $output
        } else {
            $tenantInfoOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($tenantInfoOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($tenantInfoOutput.Diagnostic)

            $supportedLanguagesOutput = @()
            foreach ($supportedLanguage in $tenantInfoOutput.TenantInformationSupportedLanguage) {
                $languageOutput = [Microsoft.Rtc.Management.Hosted.OAA.Models.Language]::new()
                $languageOutput.ParseFrom($supportedLanguage)
                $supportedLanguagesOutput += $languageOutput
            }

            $supportedLanguagesOutput
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantSupportedTimeZone {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter specifies a time zone to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Use ResponseType 1 as binary output
        if ($PSBoundParameters.ContainsKey('Identity')) {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantSupportedTimeZone @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.TimeZone]::new()
            $output.ParseFrom($internalOutput)

            $output
        } else {
            $tenantInfoOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($tenantInfoOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($tenantInfoOutput.Diagnostic)

            $supportedTimezonesOutput = @()
            foreach ($supportedTimezone in $tenantInfoOutput.TenantInformationSupportedTimeZone) {
                $timezoneOutput = [Microsoft.Rtc.Management.Hosted.OAA.Models.TimeZone]::new()
                $timezoneOutput.ParseFrom($supportedTimezone)
                $supportedTimezonesOutput += $timezoneOutput
            }

            $supportedTimezonesOutput
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantTenantInformation {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.TenantInformation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsCallQueue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The identity of the call queue which is retrieved.
        ${Identity},

        [Parameter(Mandatory=$false)]
        [int]
        # The First parameter gets the first N Call Queues.
        ${First},

        [Parameter(Mandatory=$false)]
        [int]
        # The Skip parameter skips the first N Call Queues. It is intended to be used for pagination purposes.
        ${Skip},

        [Parameter(Mandatory=$false)]
        [switch]
        # The ExcludeContent parameter only displays the Name and Id of the Call Queues.
        ${ExcludeContent},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The Sort parameter specifies the property used to sort.
        ${Sort},

        [Parameter(Mandatory=$false)]
        [switch]
        # The Descending parameter is used to sort descending.
        ${Descending},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The NameFilter parameter returns Call Queues where name contains specified string
        ${NameFilter},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        if (${Identity} -and (${First} -or ${Skip} -or ${Sort} -or ${Descending} -or ${NameFilter})) {
            throw "Identity parameter cannot be used with any other parameter."
        }

        # Set the 'FilterInvalidObos' query parameter value to false.
        $PSBoundParameters.Add('FilterInvalidObos', $false)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Endpoint to get single entity does not support content exclusion, so we will filter content when displaying
        if ($PSBoundParameters.ContainsKey('Identity') -and $PSBoundParameters.ContainsKey('ExcludeContent')) {
            $PSBoundParameters.Remove("ExcludeContent")
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        if (${Identity} -ne '') {
            $callQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
            $callQueue.ParseFrom($result.CallQueue, $ExcludeContent)
        } else {
            $callQueues = @()
            foreach ($model in $result.CallQueue) {
                $callQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
                $callQueues += $callQueue.ParseFrom($model, $ExcludeContent)
            }
            $callQueues
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsOnlineApplicationInstanceAssociation {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the application instance whose association is to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Encode the given "Identity" if it is a SIP URI (aka User Principle Name (UPN))
        $PSBoundParameters['Identity']  = EncodeSipUri($PSBoundParameters['Identity'])

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineApplicationInstanceAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.ApplicationInstanceAssociation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsOnlineApplicationInstanceAssociationStatus {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the application instance whose association provisioning status is to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineApplicationInstanceAssociationStatus @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
        
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.StatusRecord]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Get-CsOnlineAudioFile

function Get-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId}
    )

    process {
        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }

        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Identity -ne "") {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineAudioFile @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
            $output.ParseFrom($internalOutput)
        }
        else {
            $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineAudioFile @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutputs -eq $null) {
                return $null
            }

            $output = New-Object Collections.Generic.List[Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]
            foreach($internalOutput in $internalOutputs) {
                $audioFile = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
                $audioFile.ParseFrom($internalOutput)
                $output.Add($audioFile)
            }
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsOnlineSchedule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The identity of the schedule which is retrieved.
        ${Id},
        
        [Parameter(Mandatory=$false)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }
        
        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineSchedule @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        if (${Id} -ne '') {
            $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
            $schedule.ParseFrom($result)
        } else {
            $schedules = @()
            foreach ($model in $result.Schedule) {
                $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
                $schedules += $schedule.ParseFrom($model)
            }
            $schedules
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsOnlineVoicemailUserSettings {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the user for the voice mail settings
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineVMUserSetting @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        $result
            
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Import-CsAutoAttendantHolidays {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be imported.
        ${Identity},

        [Alias('Input')]
        [Parameter(Mandatory=$true, position=1)]
        [System.Byte[]]
        ${InputBytes},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        $base64input = [System.Convert]::ToBase64String($InputBytes)
        $PSBoundParameters.Add("SerializedHolidayRecord", $base64input)
        $null = $PSBoundParameters.Remove("InputBytes")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Import-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalImportHolidayStatus in $internalOutput.ImportAutoAttendantHolidayResultImportHolidayStatusRecord)
        {
            $importHolidayStatus = [Microsoft.Rtc.Management.Hosted.OAA.Models.HolidayImportResult]::new()
            $importHolidayStatus.ParseFrom($internalImportHolidayStatus)
            $output += $importHolidayStatus
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Base64 encode the content for the audio file

function Import-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The FileName parameter is the name of the audio file.
        ${FileName},

        [Parameter(Mandatory=$true, position=2)]
        [System.Byte[]]
        # The Content parameter represents the content of the audio file.
        ${Content},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        $base64content = [System.Convert]::ToBase64String($Content)
        $null = $PSBoundParameters.Remove("Content")
        $PSBoundParameters.Add("Content", $base64content)

        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }
        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Import-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function New-CsAutoAttendant {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter is a friendly name that is assigned to the AA.
        ${Name},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The LanguageId parameter is the language that is used to read text-to-speech (TTS) prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false, position=2)]
        [System.String]
        # The VoiceId parameter represents the voice that is used to read text-to-speech (TTS) prompts.
        ${VoiceId},

        [Parameter(Mandatory=$true, position=3)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]
        # The DefaultCallFlow parameter is the flow to be executed when no other call flow is in effect (for example, during business hours).
        ${DefaultCallFlow},

        [Parameter(Mandatory=$false, position=4)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]
        # The Operator parameter represents the address or PSTN number of the operator.
        ${Operator},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        # The EnableVoiceResponse parameter indicates whether voice response for AA is enabled.
        ${EnableVoiceResponse},

        [Parameter(Mandatory=$true, position=6)]
        [System.String]
        # The TimeZoneId parameter represents the AA time zone.
        ${TimeZoneId},

        [Parameter(Mandatory=$false, position=7)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow[]]
        # The CallFlows parameter represents call flows, which are required if they are referenced in the CallHandlingAssociations parameter.
        ${CallFlows},

        [Parameter(Mandatory=$false, position=8)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation[]]
        # The CallHandlingAssociations parameter represents the call handling associations.
        ${CallHandlingAssociations},

        [Parameter(Mandatory=$false, position=9)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]
        # Specifies the users to which call transfers are allowed through directory lookup feature.
        ${InclusionScope},

        [Parameter(Mandatory=$false, position=10)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]
        # Specifies the users to which call transfers are not allowed through directory lookup feature.
        ${ExclusionScope},

        [Parameter(Mandatory=$false, position=11)]
        [System.Guid[]]
        # The list of authorized users.
        ${AuthorizedUsers},

        [Parameter(Mandatory=$false, position=12)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Name")
        $null = $PSBoundCommonParameters.Remove("LanguageId")
        $null = $PSBoundCommonParameters.Remove("VoiceId")
        $null = $PSBoundCommonParameters.Remove("DefaultCallFlow")
        $null = $PSBoundCommonParameters.Remove("Operator")
        $null = $PSBoundCommonParameters.Remove("EnableVoiceResponse")
        $null = $PSBoundCommonParameters.Remove("TimeZoneId")
        $null = $PSBoundCommonParameters.Remove("CallFlows")
        $null = $PSBoundCommonParameters.Remove("CallHandlingAssociations")
        $null = $PSBoundCommonParameters.Remove("InclusionScope")
        $null = $PSBoundCommonParameters.Remove("ExclusionScope")
        $null = $PSBoundCommonParameters.Remove("AuthorizedUsers")

        if ($DefaultCallFlow -ne $null) {
            $null = $PSBoundParameters.Remove('DefaultCallFlow')
            if ($DefaultCallFlow.Id -ne $null) {
                $PSBoundParameters.Add('DefaultCallFlowId', $DefaultCallFlow.Id)
            }
            if ($DefaultCallFlow.Greetings -ne $null) {
                $defaultCallFlowGreetings = @()
                foreach ($defaultCallFlowGreeting in $DefaultCallFlow.Greetings) {
                    $defaultCallFlowGreetings += $defaultCallFlowGreeting.ParseToAutoGeneratedModel()
                }
                $PSBoundParameters.Add('DefaultCallFlowGreeting', $defaultCallFlowGreetings)
            }
            if ($DefaultCallFlow.Name -ne $null) {
                $PSBoundParameters.Add('DefaultCallFlowName', $DefaultCallFlow.Name)
            }
            if ($DefaultCallFlow.Menu -ne $null) {
                if ($DefaultCallFlow.Menu.DialByNameEnabled) {
                    $PSBoundParameters.Add('MenuDialByNameEnabled', $true)
                }
                $PSBoundParameters.Add('MenuDirectorySearchMethod', $DefaultCallFlow.Menu.DirectorySearchMethod.ToString())
                if ($DefaultCallFlow.Menu.Name -ne $null) {
                    $PSBoundParameters.Add('MenuName', $DefaultCallFlow.Menu.Name)
                }
                if ($DefaultCallFlow.Menu.MenuOptions -ne $null) {
                    $defaultCallFlowMenuOptions = @()
                    foreach ($defaultCallFlowMenuOption in $DefaultCallFlow.Menu.MenuOptions) {
                        $defaultCallFlowMenuOptions += $defaultCallFlowMenuOption.ParseToAutoGeneratedModel()
                    }
                    $PSBoundParameters.Add('MenuOption', $defaultCallFlowMenuOptions)
                }
                if ($DefaultCallFlow.Menu.Prompts -ne $null) {
                    $defaultCallFlowMenuPrompts = @()
                    foreach ($defaultCallFlowMenuPrompt in $DefaultCallFlow.Menu.Prompts) {
                        $defaultCallFlowMenuPrompts += $defaultCallFlowMenuPrompt.ParseToAutoGeneratedModel()
                    }
                    $PSBoundParameters.Add('MenuPrompt', $defaultCallFlowMenuPrompts)
                }
            }
        }
        if ($CallFlows -ne $null) {
            $null = $PSBoundParameters.Remove('CallFlows')
            $inputCallFlows = @()
            foreach ($callFlow in $CallFlows) {
                $inputCallFlows += $callFlow.ParseToAutoGeneratedModel()
            }
            $PSBoundParameters.Add('CallFlow', $inputCallFlows)
        }
        if ($CallHandlingAssociations -ne $null) {
            $null = $PSBoundParameters.Remove('CallHandlingAssociations')
            $inputCallHandlingAssociations = @()
            foreach ($callHandlingAssociation in $CallHandlingAssociations) {
                $inputCallHandlingAssociations += $callHandlingAssociation.ParseToAutoGeneratedModel()
            }
            $PSBoundParameters.Add('CallHandlingAssociation', $inputCallHandlingAssociations)
        }
        if ($Operator -ne $null) {
            $null = $PSBoundParameters.Remove('Operator')
            $PSBoundParameters.Add('OperatorEnableTranscription', $Operator.EnableTranscription)
            $PSBoundParameters.Add('OperatorId', $Operator.Id)
            $PSBoundParameters.Add('OperatorType', $Operator.Type.ToString())
        }
        if ($InclusionScope -ne $null) {
            $null = $PSBoundParameters.Remove('InclusionScope')
            $PSBoundParameters.Add('InclusionScopeType', $InclusionScope.Type.ToString())
            $PSBoundParameters.Add('InclusionScopeGroupDialScopeGroupId', $InclusionScope.GroupScope.GroupIds)
        }
        if ($ExclusionScope -ne $null) {
            $null = $PSBoundParameters.Remove('ExclusionScope')
            $PSBoundParameters.Add('ExclusionScopeType', $ExclusionScope.Type.ToString())
            $PSBoundParameters.Add('ExclusionScopeGroupDialScopeGroupId', $ExclusionScope.GroupScope.GroupIds)
        }
        if ($AuthorizedUsers -ne $null) {
            $null = $PSBoundParameters.Remove('AuthorizedUsers')
            $inputAuthorizedUsers = @()
            foreach ($authorizedUser in $AuthorizedUsers) {
                $inputAuthorizedUsers += $authorizedUser.ToString()
            }
            $PSBoundParameters.Add('AuthorizedUser', $inputAuthorizedUsers)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
        $output.ParseFrom($internalOutput.AutoAttendant)

        $getCsAutoAttendantStatusParameters = @{Identity = $output.Identity}
        foreach($p in $PSBoundCommonParameters.GetEnumerator())
        {
            $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
        }

        $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters
        $output.AmendStatus($internalStatus)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function New-CsAutoAttendantCallableEntity {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter represents the ID of the callable entity
        ${Identity},

        [Parameter(Mandatory=$true, position=1)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntityType]
        # The Type parameter represents the type of the callable entity
        ${Type},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # Enables the email transcription of voicemail, this is only supported with shared voicemail callable entities.
        ${EnableTranscription},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # Suppresses the "Please leave a message after the tone" system prompt when transferring to shared voicemail.
        ${EnableSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallableEntity @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Put nested ApplicationInstance object as first layer object

function New-CsAutoAttendantCallFlow {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter represents a unique friendly name for the call flow.
        ${Name},

        [Parameter(Mandatory=$false, position=1)]
        [PSObject[]]
        # If present, the prompts specified by the Greetings parameter (either TTS or Audio) are played before the call flow's menu is rendered.
        ${Greetings},

        [Parameter(Mandatory=$true, position=2)]
        [PSObject]
        # The Menu parameter identifies the menu to render when the call flow is executed.
        ${Menu},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Greetings -ne $null) {
            $null = $PSBoundParameters.Remove('Greetings')
            $inputGreetings = @()
            foreach ($greeting in $Greetings) {
                $inputGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($greeting)
            }
            $PSBoundParameters.Add('Greeting', $inputGreetings)
        }

        if ($Menu -ne $null) {
            $null = $PSBoundParameters.Remove('Menu')
            if ($Menu.DialByNameEnabled) {
                $PSBoundParameters.Add('MenuDialByNameEnabled', $true)
            }
            $PSBoundParameters.Add('MenuDirectorySearchMethod', $Menu.DirectorySearchMethod)
            $PSBoundParameters.Add('MenuName', $Menu.Name)
            $inputMenuOptions = @()
            foreach ($menuOption in $Menu.MenuOptions) {
                $inputMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
            }
            $PSBoundParameters.Add('MenuOption', $inputMenuOptions)
            $inputMenuPrompts = @()
            foreach ($menuPrompt in $Menu.Prompts) {
                $inputMenuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($menuPrompt)
            }
            $PSBoundParameters.Add('MenuPrompt', $inputMenuPrompts)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallFlow @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print diagnostic message from service

function New-CsAutoAttendantCallHandlingAssociation {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociationType]
        # The Type parameter represents the type of the call handling association.
        ${Type},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The ScheduleId parameter represents the schedule to be associated with the call flow.
        ${ScheduleId},

        [Parameter(Mandatory=$true, position=2)]
        [System.String]
        # The CallFlowId parameter represents the call flow to be associated with the schedule.
        ${CallFlowId},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The Disable parameter, if set, establishes that the call handling association is created as disabled.
        ${Disable},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        if ($Disable -eq $true) {
            $null = $PSBoundParameters.Remove('Disable')
        } else {
            $PSBoundParameters.Add('Enable', $true)
        }

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallHandlingAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print diagnostic message from server respond

function New-CsAutoAttendantDialScope {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Switch]
        # Indicates that a dial-scope based on groups (distribution lists, security groups) is to be created.
        ${GroupScope},

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        # Refers to the IDs of the groups that are to be included in the dial-scope.
        ${GroupIds},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        if ($GroupScope -eq $true) {
            $null = $PSBoundParameters.Remove('GroupScope')
        }

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantDialScope @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format input of the cmdlet

function New-CsAutoAttendantMenu {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter represents a friendly name for the menu.
        ${Name},

        [Parameter(Mandatory=$false, position=1)]
        [PSObject[]]
        # The Prompts parameter reflects the prompts to play when the menu is activated.
        ${Prompts},

        [Parameter(Mandatory=$false, position=2)]
        [PSObject[]]
        # The MenuOptions parameter is a list of menu options for this menu.
        ${MenuOptions},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The EnableDialByName parameter lets users do a directory search by recipient name and get transferred to the party.
        ${EnableDialByName},

        [Parameter(Mandatory=$false, position=4)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DirectorySearchMethod]
        # The DirectorySearchMethod parameter lets you define the type of Directory Search Method for the Auto Attendant menu.
        ${DirectorySearchMethod},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Prompts -ne $null) {
            $null = $PSBoundParameters.Remove('Prompts')
            $inputPrompts = @()
            foreach ($prompt in $Prompts) {
                $inputPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($prompt)
            }
            $PSBoundParameters.Add('Prompt', $inputPrompts)
        }

        if ($MenuOptions -ne $null) {
            $null = $PSBoundParameters.Remove('MenuOptions')
            $inputMenuOptions = @()
            foreach ($menuOption in $MenuOptions) {
                $inputMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
            }
            $PSBoundParameters.Add('MenuOption', $inputMenuOptions)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantMenu @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Menu]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format input of the cmdlet

function New-CsAutoAttendantMenuOption {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.ActionType]
        # The Action parameter represents the action to be taken when the menu option is activated. 
        ${Action},

        [Parameter(Mandatory=$true, position=1)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DtmfTone]
        # The DtmfResponse parameter indicates the key on the telephone keypad to be pressed to activate the menu option. 
        ${DtmfResponse},

        [Parameter(Mandatory=$false, position=2)]
        [System.String[]]
        # The VoiceResponses parameter represents the voice responses to select a menu option when Voice Responses are enabled for the auto attendant.
        ${VoiceResponses},

        [Parameter(Mandatory=$false, position=3)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]
        # The CallTarget parameter represents the target for call transfer after the menu option is selected.
        ${CallTarget},

        [Parameter(Mandatory=$false, position=4)]
        [PSObject]
        # The Prompt parameter represents the announcement prompt.
        ${Prompt},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($CallTarget -ne $null) {
            $null = $PSBoundParameters.Remove('CallTarget')
            $PSBoundParameters.Add('CallTargetId', $CallTarget.Id)
            $PSBoundParameters.Add('CallTargetType', $CallTarget.Type)
            if ($CallTarget.EnableTranscription) {
                $PSBoundParameters.Add('CallTargetEnableTranscription', $True)
            }
            if ($CallTarget.EnableSharedVoicemailSystemPromptSuppression) {
                $PSBoundParameters.Add('CallTargetEnableSharedVoicemailSystemPromptSuppression', $True)
            }
        }

        if ($Prompt -ne $null) {
            $typeNames = $Prompt.PSObject.TypeNames
            if ($typeNames -NotContains "Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt" -and $typeNames -NotContains "Deserialized.Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt") {
                throw "PSObject must be type of Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt or Deserialized.Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt"
            }
            
            $null = $PSBoundParameters.Remove('Prompt')
            $PSBoundParameters.Add('PromptActiveType', $Prompt.ActiveType)
            $PSBoundParameters.Add('PromptTextToSpeechPrompt', $Prompt.TextToSpeechPrompt)
            if ($Prompt.AudioFilePrompt -ne $null -and $Prompt.AudioFilePrompt.Id -ne $null) {
                $PSBoundParameters.Add('AudioFilePromptId', $Prompt.AudioFilePrompt.Id)
                $PSBoundParameters.Add('AudioFilePromptFileName', $Prompt.AudioFilePrompt.FileName)
                $PSBoundParameters.Add('AudioFilePromptDownloadUri', $Prompt.AudioFilePrompt.DownloadUri)
            }
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantMenuOption @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Base64 encode the content for the audio file

function New-CsAutoAttendantPrompt {
    [CmdletBinding(PositionalBinding=$true, DefaultParameterSetName='TextToSpeechParamSet')]
    param(
        [Parameter(Mandatory=$true, position=0, ParameterSetName="DualParamSet")]
        [System.String]
        # The ActiveType parameter identifies the active type (modality) of the AA prompt. 
        ${ActiveType},

        [Parameter(Mandatory=$true, position=0, ParameterSetName="AudioFileParamSet")]
        [Parameter(Mandatory=$false, position=1, ParameterSetName="DualParamSet")]
        [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]
        # The AudioFilePrompt parameter represents the audio to play when the prompt is activated (rendered).
        ${AudioFilePrompt},

        [Parameter(Mandatory=$true, position=0, ParameterSetName="TextToSpeechParamSet")]
        [Parameter(Mandatory=$false, position=2, ParameterSetName="DualParamSet")]
        [System.String]
        # The TextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt that is to be read when the prompt is activated.
        ${TextToSpeechPrompt}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($ActiveType -eq "") {
            $PSBoundParameters.Remove("ActiveType") | Out-Null
            if ($TextToSpeechPrompt -ne "") {
                $PSBoundParameters.Add("ActiveType", "TextToSpeech")
            } elseif ($AudioFilePrompt -ne $null) {
                $PSBoundParameters.Add("ActiveType", "AudioFile")
            } else {
                $PSBoundParameters.Add("ActiveType", "None")
            }
        }

        $ActiveType = "TextToSpeech"

        if ($AudioFilePrompt -ne $null) {
            $PSBoundParameters.Add('AudioFilePromptId', $AudioFilePrompt.Id)
            $PSBoundParameters.Add('AudioFilePromptFileName', $AudioFilePrompt.FileName)
            $PSBoundParameters.Add('AudioFilePromptDownloadUri', $AudioFilePrompt.DownloadUri)
            $PSBoundParameters.Remove('AudioFilePrompt') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantPrompt @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::new()
        $output.ParseFrom($internalOutput)

        return $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: parsing the return result to the CallQueue object type.

function New-CsCallQueue {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name of the call queue to be created.
        ${Name},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The AgentAlertTime parameter represents the time (in seconds) that a call can remain unanswered before it is automatically routed to the next agent.
        ${AgentAlertTime},

        [Parameter(Mandatory=$false)]
        [bool]
        # The AllowOptOut parameter indicates whether or not agents can opt in or opt out from taking calls from a Call Queue.
        ${AllowOptOut},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The DistributionLists parameter lets you add all the members of the distribution lists to the Call Queue. This is a list of distribution list GUIDs.
        ${DistributionLists},

        [Parameter(Mandatory=$false)]
        [bool]
        # The UseDefaultMusicOnHold parameter indicates that this Call Queue uses the default music on hold.
        ${UseDefaultMusicOnHold},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The WelcomeMusicAudioFileId parameter represents the audio file to play when callers are connected with the Call Queue.
        ${WelcomeMusicAudioFileId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The MusicOnHoldAudioFileId parameter represents music to play when callers are placed on hold.
        ${MusicOnHoldAudioFileId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.OverflowAction]
        # The OverflowAction parameter designates the action to take if the overflow threshold is reached.
        ${OverflowAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowActionTarget parameter represents the target of the overflow action.
        ${OverflowActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The OverflowThreshold parameter defines the number of calls that can be in the queue at any one time before the overflow action is triggered.
        ${OverflowThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.TimeoutAction]
        # The TimeoutAction parameter defines the action to take if the timeout threshold is reached.
        ${TimeoutAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutActionTarget represents the target of the timeout action.
        ${TimeoutActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The TimeoutThreshold parameter defines the time (in seconds) that a call can be in the queue before that call times out.
        ${TimeoutThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.RoutingMethod]
        # The RoutingMethod defines how agents will be called in a Call Queue.
        ${RoutingMethod},

        [Parameter(Mandatory=$false)]
        [bool]
        # The PresenceBasedRouting parameter indicates whether or not presence based routing will be applied while call being routed to Call Queue agents.
        ${PresenceBasedRouting},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ConferenceMode parameter indicates whether or not Conference mode will be applied on calls for current call queue.
        ${ConferenceMode},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The Users parameter lets you add agents to the Call Queue.
        ${Users},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The LanguageId parameter indicates the language that is used to play shared voicemail prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # This parameter is reserved for Microsoft internal use only.
        ${LineUri},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The OboResourceAccountIds parameter lets you add resource account with phone number to the Call Queue.
        ${OboResourceAccountIds},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on overflow.
        ${EnableOverflowSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailSystemPromptSuppression parameter is used to disable voicemail system message on overflow.
        ${EnableOverflowSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on timeout.
        ${EnableTimeoutSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailSystemPromptSuppression parameter is used to disable voicemail system message on timeout.
        ${EnableTimeoutSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Id of the channel to connect a call queue to.
        ${ChannelId},

        [Parameter(Mandatory=$false)]
        [System.Guid]
        # Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
        ${ChannelUserObjectId},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ShouldOverwriteCallableChannelProperty indicates user intention to whether overwirte the current callableChannel property value on chat service or not.
        ${ShouldOverwriteCallableChannelProperty},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The list of authorized users.
        ${AuthorizedUsers},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        if ($PSBoundParameters.ContainsKey('LineUri')) {
            # Stick with the current TRPS cmdlet policy of silently ignoring the LineUri. Later, we need to remove this param from
            # TRPS and ConfigAPI based cmdlets. Public facing document must be updated as well.
            $PSBoundParameters.Remove('LineUri') | Out-Null
        }

        if ($PresenceBasedRouting -ne $null) {
            $PSBoundParameters.Add('PresenceAwareRouting', $PresenceBasedRouting)
            $PSBoundParameters.Remove('PresenceBasedRouting') | Out-Null
        }

        if ($ChannelId -ne '') {
            $PSBoundParameters.Add('ThreadId', $ChannelId)
            $PSBoundParameters.Remove('ChannelId') | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsCallQueue @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $output.ParseFrom($result.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function New-CsOnlineApplicationInstanceAssociation {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # The Identities parameter is the identities of application instances to be associated with the provided configuration ID.
        ${Identities},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The ConfigurationId parameter is the identity of the configuration that would be associatied with the provided application instances.
        ${ConfigurationId},

        [Parameter(Mandatory=$true, position=2)]
        [System.String]
        # The ConfigurationType parameter denotes the type of the configuration that would be associated with the provided application instances.
        ${ConfigurationType},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineApplicationInstanceAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutputs -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutputs.Diagnostic)
        
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AssociationOperationOutput]::new()
        $output.ParseFrom($internalOutputs)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the return result to the custom object

function New-CsOnlineDateTimeRange {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Start parameter represents the start bound of the date-time range.
        ${Start},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The End parameter represents the end bound of the date-time range.
        ${End},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineDateTimeRange @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.DateTimeRange]::new()
        $output.ParseFrom($result)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: assign parameters' values and customize output

function New-CsOnlineSchedule {
    [CmdletBinding(DefaultParameterSetName="UnresolvedParamSet", SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # The name of the schedule which is created.
        ${Name},

        [Parameter(Mandatory=$true, ParameterSetName = "FixedScheduleParamSet")]
        [switch]
        # The FixedSchedule parameter indicates that a fixed schedule is to be created.
        ${FixedSchedule},

        [Parameter(Mandatory=$false, ParameterSetName = "FixedScheduleParamSet")]
        # List of date-time ranges for a fixed schedule.
        ${DateTimeRanges},

        [Parameter(Mandatory=$true, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        [switch]
        # The WeeklyRecurrentSchedule parameter indicates that a weekly recurrent schedule is to be created.
        ${WeeklyRecurrentSchedule},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Monday.
        ${MondayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Tuesday.
        ${TuesdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Wednesday.
        ${WednesdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Thursday.
        ${ThursdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Friday.
        ${FridayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Saturday.
        ${SaturdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Sunday.
        ${SundayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        [switch]
        # The flag for Complement enabled or not
        ${Complement},

        [Parameter(Mandatory=$false)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $dateTimeRangeStandardFormat = 'yyyy-MM-ddTHH:mm:ss';

        # Get common parameters
        $params = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $params += @{$p.Key = $p.Value}
        }
        $null = $params.Remove("FixedSchedule")
        $null = $params.Remove("DateTimeRanges")
        $null = $params.Remove("WeeklyRecurrentSchedule")
        $null = $params.Remove("MondayHours")
        $null = $params.Remove("TuesdayHours")
        $null = $params.Remove("WednesdayHours")
        $null = $params.Remove("ThursdayHours")
        $null = $params.Remove("FridayHours")
        $null = $params.Remove("SaturdayHours")
        $null = $params.Remove("SundayHours")
        $null = $params.Remove("Complement")


        if ($PsCmdlet.ParameterSetName -eq "UnresolvedParamSet") {
            throw "A schedule type must be specified. Please use -WeeklyRecurrentSchedule or -FixedSchedule parameters to create the appropriate type of schedule."
        }

        if ($PsCmdlet.ParameterSetName -eq "FixedScheduleParamSet") {
            $fixedScheduleDateTimeRanges = @()
            foreach ($dateTimeRange in $DateTimeRanges) {
                $fixedScheduleDateTimeRanges += @{
                    Start = $dateTimeRange.Start.ToString($dateTimeRangeStandardFormat, [System.Globalization.CultureInfo]::InvariantCulture)
                    End = $dateTimeRange.End.ToString($dateTimeRangeStandardFormat, [System.Globalization.CultureInfo]::InvariantCulture)
                }
            }
            $params['FixedScheduleDateTimeRange'] = $fixedScheduleDateTimeRanges
        }

        if ($PsCmdlet.ParameterSetName -eq "WeeklyRecurrentScheduleParamSet") {
            if ($MondayHours -ne $null -and $MondayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleMondayHour'] = @()
                foreach ($mondayHour in $MondayHours){
                    $params['WeeklyRecurrentScheduleMondayHour'] += @{
                        Start = $mondayHour.Start
                        End = $mondayHour.End
                    }
                }
            }
            if ($TuesdayHours -ne $null -and $TuesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleTuesdayHour'] = @()
                foreach ($tuesdayHour in $TuesdayHours){
                    $params['WeeklyRecurrentScheduleTuesdayHour'] += @{
                        Start = $tuesdayHour.Start
                        End = $tuesdayHour.End
                    }
                }
            }
            if ($WednesdayHours -ne $null -and $WednesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleWednesdayHour'] = @()
                foreach ($wednesdayHour in $WednesdayHours){
                    $params['WeeklyRecurrentScheduleWednesdayHour'] += @{
                        Start = $wednesdayHour.Start
                        End = $wednesdayHour.End
                    }
                }    
            }
            if ($ThursdayHours -ne $null -and $ThursdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleThursdayHour'] = @()
                    foreach ($thursdayHour in $ThursdayHours){
                        $params['WeeklyRecurrentScheduleThursdayHour'] += @{
                            Start = $thursdayHour.Start
                            End = $thursdayHour.End
                    }
                }
            }
            if ($FridayHours -ne $null -and $FridayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleFridayHour'] = @()
                foreach ($fridayHour in $FridayHours){
                    $params['WeeklyRecurrentScheduleFridayHour'] += @{
                        Start = $fridayHour.Start
                        End = $fridayHour.End
                    }
                }
            }
            if ($SaturdayHours -ne $null -and $SaturdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSaturdayHour'] = @()
                foreach ($saturdayHour in $SaturdayHours){
                    $params['WeeklyRecurrentScheduleSaturdayHour'] += @{
                        Start = $saturdayHour.Start
                        End = $saturdayHour.End
                    }
                }
            }
            if ($SundayHours -ne $null -and $SundayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSundayHour'] = @()
                foreach ($sundayHour in $SundayHours){
                    $params['WeeklyRecurrentScheduleSundayHour'] += @{
                        Start = $sundayHour.Start
                        End = $sundayHour.End
                    }
                }
            }
            if ($Complement) { $params['WeeklyRecurrentScheduleIsComplemented'] = $true }
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineSchedule @params

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
        $schedule.ParseFrom($result)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the return result to the custom object

function New-CsOnlineTimeRange {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Start parameter represents the start bound of the time range.
        ${Start},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The End parameter represents the end bound of the time range.
        ${End},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineTimeRange @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.TimeRange]::new()
        $output.ParseFrom($result)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Display the diagnostic if any

function Remove-CsAutoAttendant {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be removed.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: print out the diagnostics

function Remove-CsCallQueue {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identifier of the call queue to be removed.
        ${Identity},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        # Default ErrorAction to Stop
        if (!$PSBoundParameters.ContainsKey('ErrorAction')) {
            $PSBoundParameters.Add('ErrorAction', 'Stop')
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the CallQueue to be deleted by Identity.
        $getParams = @{Identity = $Identity; FilterInvalidObos = $false}
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams -ErrorAction Stop

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsCallQueue @PSBoundParameters
        Write-AdminServiceDiagnostic($result.Diagnostics)

        # Convert the fecthed CallQueue DTO to domain model and print.
        $deletedCallQueue= [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $deletedCallQueue.ParseFrom($getResult.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Remove-CsOnlineApplicationInstanceAssociation {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # The Identity parameter is the identity of application instances to be associated with the provided configuration ID.
        ${Identities},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the array of Identities, and remove parameter 'Identities',
        # since api internal\Remove-CsOnlineApplicationInstanceAssociation takes only param 'Identity' as a string,
        # so need send a request for each identity (endpointId) by looping through all Identities.
        $endpointIdArr = @()

        if ($PSBoundParameters.ContainsKey('Identities')) {
            $endpointIdArr = $PSBoundParameters['Identities']
            $PSBoundParameters.Remove('Identities') | Out-Null
        }

        # Sends request for each identity (endpointId)
        foreach ($endpointId in $endpointIdArr) {
            # Encode the "endpointID" if it is a SIP URI (aka User Principle Name (UPN))
            $identity  = EncodeSipUri($endpointId)
            $PSBoundParameters.Add('Identity', $identity)

            $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineApplicationInstanceAssociation @PSBoundParameters
            $PSBoundParameters.Remove('Identity') | Out-Null

            # Stop execution if internal cmdlet is failing
            if ($internalOutputs -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutputs.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AssociationOperationOutput]::new()
            $output.ParseFrom($internalOutputs)

            $output
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Add default App ID for Remove-CsOnlineAudioFile

function Remove-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity}
    )

    process {
        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", "TenantGlobal")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        $internalOutput
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: print out the diagnostic

function Remove-CsOnlineSchedule {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identifier of the schedule to be removed.
        ${Id},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineSchedule @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $result
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function Set-CsAutoAttendant {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [PSObject]
        # The Instance parameter is the object reference to the AA to be modified.
        ${Instance},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Instance")
        $null = $PSBoundCommonParameters.Remove("WhatIf")
        $null = $PSBoundCommonParameters.Remove("Confirm")

        $null = $PSBoundParameters.Remove('Instance')
        if ($Instance.Identity -ne $null) {
            $PSBoundParameters.Add('Identity', $Instance.Identity)
        }
        if ($Instance.Id -ne $null) {
            $PSBoundParameters.Add('Id', $Instance.Id)
        }
        if ($Instance.Name -ne $null) {
            $PSBoundParameters.Add('Name', $Instance.Name)
        }
        if ($Instance.LanguageId -ne $null) {
            $PSBoundParameters.Add('LanguageId', $Instance.LanguageId)
        }
        if ($Instance.TimeZoneId -ne $null) {
            $PSBoundParameters.Add('TimeZoneId', $Instance.TimeZoneId)
        }
        if ($Instance.TenantId -ne $null) {
            $PSBoundParameters.Add('TenantId', $Instance.TenantId.ToString())
        }
        if ($Instance.VoiceId -ne $null) {
            $PSBoundParameters.Add('VoiceId', $Instance.VoiceId)
        }
        if ($Instance.DialByNameResourceId -ne $null) {
            $PSBoundParameters.Add('DialByNameResourceId', $Instance.DialByNameResourceId)
        }
        if ($Instance.ApplicationInstances -ne $null) {
            $PSBoundParameters.Add('ApplicationInstance', $Instance.ApplicationInstances)
        }
        if ($Instance.VoiceResponseEnabled -eq $true) {
            $PSBoundParameters.Add('VoiceResponseEnabled', $true)
        }
        if ($Instance.DefaultCallFlow -ne $null) {
            $PSBoundParameters.Add('DefaultCallFlowId', $Instance.DefaultCallFlow.Id)
            $PSBoundParameters.Add('DefaultCallFlowName', $Instance.DefaultCallFlow.Name)
            $defaultCallFlowGreetings = @()
            if ($Instance.DefaultCallFlow.Greetings -ne $null) {
                foreach ($defaultCallFlowGreeting in $Instance.DefaultCallFlow.Greetings) {
                    $defaultCallFlowGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($defaultCallFlowGreeting)
                }
                $PSBoundParameters.Add('DefaultCallFlowGreeting', $defaultCallFlowGreetings)
            }
            if ($Instance.DefaultCallFlow.Menu -ne $null) {
                $PSBoundParameters.Add('MenuDialByNameEnabled', $Instance.DefaultCallFlow.Menu.DialByNameEnabled)
                $PSBoundParameters.Add('MenuDirectorySearchMethod', $Instance.DefaultCallFlow.Menu.DirectorySearchMethod.ToString())
                $PSBoundParameters.Add('MenuName', $Instance.DefaultCallFlow.Menu.Name)
                if ($Instance.DefaultCallFlow.Menu.MenuOptions -ne $null) {
                    $defaultCallFlowMenuOptions = @()
                    foreach($defaultCallFlowMenuOption in $Instance.DefaultCallFlow.Menu.MenuOptions) {
                        $defaultCallFlowMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($defaultCallFlowMenuOption)
                    }
                    $PSBoundParameters.Add('MenuOption', $defaultCallFlowMenuOptions)
                }
                if ($Instance.DefaultCallFlow.Menu.Prompts -ne $null) {
                    $defaultCallFlowMenuPrompts = @()
                    foreach($defaultCallFlowMenuPrompt in $Instance.DefaultCallFlow.Menu.Prompts) {
                        $defaultCallFlowMenuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($defaultCallFlowMenuPrompt)
                    }
                    $PSBoundParameters.Add('MenuPrompt', $defaultCallFlowMenuPrompts)
                }
            }
        }
        if ($Instance.DirectoryLookupScope -ne $null) {
            if ($Instance.DirectoryLookupScope.InclusionScope -ne $null) {
                $PSBoundParameters.Add('InclusionScopeType', $Instance.DirectoryLookupScope.InclusionScope.Type.ToString())
                if ($Instance.DirectoryLookupScope.InclusionScope.GroupScope -ne $null) {
                    $PSBoundParameters.Add('InclusionScopeGroupDialScopeGroupId', $Instance.DirectoryLookupScope.InclusionScope.GroupScope.GroupIds)
                }
            } else {
                $PSBoundParameters.Add('InclusionScopeType', "Default")
            }
            if ($Instance.DirectoryLookupScope.ExclusionScope -ne $null) {
                $PSBoundParameters.Add('ExclusionScopeType', $Instance.DirectoryLookupScope.ExclusionScope.Type.ToString())
                if ($Instance.DirectoryLookupScope.ExclusionScope.GroupScope -ne $null) {
                    $PSBoundParameters.Add('ExclusionScopeGroupDialScopeGroupId', $Instance.DirectoryLookupScope.ExclusionScope.GroupScope.GroupIds)
                }
            } else {
                $PSBoundParameters.Add('ExclusionScopeType', "Default")
            }
        }
        if ($Instance.Operator -ne $null) {
            if ($Instance.Operator.EnableTranscription -eq $true) {
                $PSBoundParameters.Add('OperatorEnableTranscription', $true)
            }
            $PSBoundParameters.Add('OperatorId', $Instance.Operator.Id)
            $PSBoundParameters.Add('OperatorType', $Instance.Operator.Type.ToString())
        }
        if ($Instance.CallFlows -ne $null) {
            $callFlows = @()
            foreach ($callFlow in $Instance.CallFlows) {
                $generatedCallFlow = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]::CreateAutoGeneratedFromObject($callFlow)

                if ($callFlow.Greetings -ne $null) {
                    $inputGreetings = @()
                    foreach ($greeting in $callFlow.Greetings) {
                        $inputGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($greeting)
                    }
                    $generatedCallFlow.Greeting = $inputGreetings
                }
                if ($callFlow.Menu.MenuOptions -ne $null) {
                    $menuOptions = @()
                    foreach ($menuOption in $callFlow.Menu.MenuOptions) {
                        $menuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
                    }
                    $generatedCallFlow.MenuOption = $menuOptions
                }
                if ($callFlow.Menu.Prompts -ne $null) {
                    $menuPrompts = @()
                    foreach ($menuPrompt in $callFlow.Menu.Prompts) {
                        $menuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($menuPrompt)
                    }
                    $generatedCallFlow.MenuPrompt = $menuPrompts
                }

                $callFlows += $generatedCallFlow
            }
            $PSBoundParameters.Add('CallFlow', $callFlows)
        }
        if ($Instance.CallHandlingAssociations -ne $null) {
            $callHandlingAssociations = @()
            foreach($callHandlingAssociation in $Instance.CallHandlingAssociations) {
                $callHandlingAssociations += [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation]::CreateAutoGeneratedFromObject($callHandlingAssociation)
            }
            $PSBoundParameters.Add('CallHandlingAssociation', $callHandlingAssociations)
        }

        $PSBoundParameters.Add('AuthorizedUser', $Instance.AuthorizedUsers)
        
        if ($Instance.Schedules -ne $null) {
            $schedules = @()
            foreach($schedule in $Instance.Schedules) {
                $schedules += [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::CreateAutoGeneratedFromObject($schedule)
            }
            $PSBoundParameters.Add('Schedule', $schedules)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
        $output.ParseFrom($internalOutput.AutoAttendant)

        $getCsAutoAttendantStatusParameters = @{Identity = $output.Identity}
        foreach($p in $PSBoundCommonParameters.GetEnumerator())
        {
            $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
        }

        $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters
        $output.AmendStatus($internalStatus)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: replacing the parameters' names.

function Set-CsCallQueue {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity of the call queue to be updated.
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The Name of the call queue to be updated.
        ${Name},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The AgentAlertTime parameter represents the time (in seconds) that a call can remain unanswered before it is automatically routed to the next agent.
        ${AgentAlertTime},

        [Parameter(Mandatory=$false)]
        [bool]
        # The AllowOptOut parameter indicates whether or not agents can opt in or opt out from taking calls from a Call Queue.
        ${AllowOptOut},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The DistributionLists parameter lets you add all the members of the distribution lists to the Call Queue. This is a list of distribution list GUIDs.
        ${DistributionLists},

        [Parameter(Mandatory=$false)]
        [bool]
        # The UseDefaultMusicOnHold parameter indicates that this Call Queue uses the default music on hold.
        ${UseDefaultMusicOnHold},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The WelcomeMusicAudioFileId parameter represents the audio file to play when callers are connected with the Call Queue.
        ${WelcomeMusicAudioFileId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The MusicOnHoldAudioFileId parameter represents music to play when callers are placed on hold.
        ${MusicOnHoldAudioFileId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.OverflowAction]
        # The OverflowAction parameter designates the action to take if the overflow threshold is reached.
        ${OverflowAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowActionTarget parameter represents the target of the overflow action.
        ${OverflowActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The OverflowThreshold parameter defines the number of calls that can be in the queue at any one time before the overflow action is triggered.
        ${OverflowThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.TimeoutAction]
        # The TimeoutAction parameter defines the action to take if the timeout threshold is reached.
        ${TimeoutAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutActionTarget represents the target of the timeout action.
        ${TimeoutActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The TimeoutThreshold parameter defines the time (in seconds) that a call can be in the queue before that call times out.
        ${TimeoutThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.RoutingMethod]
        # The RoutingMethod defines how agents will be called in a Call Queue.
        ${RoutingMethod},

        [Parameter(Mandatory=$false)]
        [bool]
        # The PresenceBasedRouting parameter indicates whether or not presence based routing will be applied while call being routed to Call Queue agents.
        ${PresenceBasedRouting},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ConferenceMode parameter indicates whether or not Conference mode will be applied on calls for current call queue.
        ${ConferenceMode},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The Users parameter lets you add agents to the Call Queue.
        ${Users},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The LanguageId parameter indicates the language that is used to play shared voicemail prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # This parameter is reserved for Microsoft internal use only.
        ${LineUri},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The OboResourceAccountIds parameter lets you add resource account with phone number to the Call Queue.
        ${OboResourceAccountIds},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on overflow.
        ${EnableOverflowSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailSystemPromptSuppression parameter is used to disable voicemail system message on overflow.
        ${EnableOverflowSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on timeout.
        ${EnableTimeoutSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailSystemPromptSuppression parameter is used to disable voicemail system message on timeout.
        ${EnableTimeoutSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Id of the channel to connect a call queue to.
        ${ChannelId},

        [Parameter(Mandatory=$false)]
        [System.Guid]
        # Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
        ${ChannelUserObjectId},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ShouldOverwriteCallableChannelProperty indicates user intention to whether overwirte the current callableChannel property value on chat service or not.
        ${ShouldOverwriteCallableChannelProperty},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The list of authorized users.
        ${AuthorizedUsers},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        # Default ErrorAction to Stop
        if (!$PSBoundParameters.ContainsKey('ErrorAction')) {
            $PSBoundParameters.Add('ErrorAction', 'Stop')
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the existing CallQueue by Identity.
        $getParams = @{Identity = $Identity; FilterInvalidObos = $false}
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams -ErrorAction Stop

        # Convert the existing CallQueue DTO to domain model.
        $existingCallQueue= [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $existingCallQueue.ParseFrom($getResult.CallQueue) | Out-Null

        # Take the delta from the existing CallQueue and apply it to the param hasthable to form
        # an appropriate DTO model for the CallQueue PUT API. FYI, CallQueue PUT API is very much
        # different from its AA counterpart which accepts params/properties to be updated only.

        # Param hashtable modification begins.
        if ($PSBoundParameters.ContainsKey('LineUri')) {
            # Stick with the current TRPS cmdlet policy of silently ignoring the LineUri. Later, we
            # need to remove this param from TRPS and ConfigAPI based cmdlets. Public facing document
            # must be updated as well.
            $PSBoundParameters.Remove('LineUri') | Out-Null
        }

        if (!$PSBoundParameters.ContainsKey('Name')) {
            $PSBoundParameters.Add('Name', $existingCallQueue.Name)
        }

        if (!$PSBoundParameters.ContainsKey('AgentAlertTime')) {
            $PSBoundParameters.Add('AgentAlertTime', $existingCallQueue.AgentAlertTime)
        }

        if ([string]::IsNullOrWhiteSpace($LanguageId) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.LanguageId)) {
            $PSBoundParameters.Add('LanguageId', $existingCallQueue.LanguageId)
        }

        if (!$PSBoundParameters.ContainsKey('OverflowThreshold')) {
            $PSBoundParameters.Add('OverflowThreshold', $existingCallQueue.OverflowThreshold)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutThreshold')) {
            $PSBoundParameters.Add('TimeoutThreshold', $existingCallQueue.TimeoutThreshold)
        }

        if (!$PSBoundParameters.ContainsKey('RoutingMethod')) {
            $PSBoundParameters.Add('RoutingMethod', $existingCallQueue.RoutingMethod)
        }

        if (!$PSBoundParameters.ContainsKey('AllowOptOut') ) {
            $PSBoundParameters.Add('AllowOptOut', $existingCallQueue.AllowOptOut)
        }

        if (!$PSBoundParameters.ContainsKey('ConferenceMode')) {
            $PSBoundParameters.Add('ConferenceMode', $existingCallQueue.ConferenceMode)
        }

        if (!$PSBoundParameters.ContainsKey('PresenceBasedRouting')) {
            $PSBoundParameters.Add('PresenceAwareRouting', $existingCallQueue.PresenceBasedRouting)
        }
        else {
            $PSBoundParameters.Add('PresenceAwareRouting', $PresenceBasedRouting)
            $PSBoundParameters.Remove('PresenceBasedRouting') | Out-Null
        }

        if (!$PSBoundParameters.ContainsKey('ChannelId')) {
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.ChannelId)) {
                $PSBoundParameters.Add('ThreadId', $existingCallQueue.ChannelId)
            }
        }
        else {
            $PSBoundParameters.Add('ThreadId', $ChannelId)
            $PSBoundParameters.Remove('ChannelId') | Out-Null
        }

        if (!$PSBoundParameters.ContainsKey('OboResourceAccountIds')) {
            if ($null -ne $existingCallQueue.OboResourceAccountIds -and $existingCallQueue.OboResourceAccountIds.Length -gt 0) {
                $PSBoundParameters.Add('OboResourceAccountIds', $existingCallQueue.OboResourceAccountIds)
            }
        }

        if (!$PSBoundParameters.ContainsKey('WelcomeMusicAudioFileId') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.WelcomeMusicResourceId)) {
            $PSBoundParameters.Add('WelcomeMusicAudioFileId', $existingCallQueue.WelcomeMusicResourceId)
        }

        if (!$PSBoundParameters.ContainsKey('MusicOnHoldAudioFileId') -and !$PSBoundParameters.ContainsKey('UseDefaultMusicOnHold')) {
            # The already persiting values cannot be conflicting as those were validated by admin service.
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.MusicOnHoldResourceId)) {
                $PSBoundParameters.Add('MusicOnHoldAudioFileId', $existingCallQueue.MusicOnHoldResourceId)
            }
            if ($null -ne $existingCallQueue.UseDefaultMusicOnHold) {
                $PSBoundParameters.Add('UseDefaultMusicOnHold', $existingCallQueue.UseDefaultMusicOnHold)
            }
        }
        elseif ($UseDefaultMusicOnHold -eq $false -and !$PSBoundParameters.ContainsKey('MusicOnHoldAudioFileId')) {
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.MusicOnHoldResourceId)) {
                $PSBoundParameters.Add('MusicOnHoldAudioFileId', $existingCallQueue.MusicOnHoldResourceId)
            }
        }

        if (!$PSBoundParameters.ContainsKey('DistributionLists')) {
            if ($null -ne $existingCallQueue.DistributionLists -and $existingCallQueue.DistributionLists.Length -gt 0) {
                $PSBoundParameters.Add('DistributionLists', $existingCallQueue.DistributionLists)
            }
        }

        if (!$PSBoundParameters.ContainsKey('Users')) {
            if ($null -ne $existingCallQueue.Users -and $existingCallQueue.Users.Length -gt 0) {
                $PSBoundParameters.Add('Users', $existingCallQueue.Users)
            }
        }

        if (!$PSBoundParameters.ContainsKey('OverflowSharedVoicemailTextToSpeechPrompt') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowSharedVoicemailTextToSpeechPrompt)) {
            $PSBoundParameters.Add('OverflowSharedVoicemailTextToSpeechPrompt', $existingCallQueue.OverflowSharedVoicemailTextToSpeechPrompt)
        }
        elseif ($PSBoundParameters.ContainsKey('OverflowSharedVoicemailTextToSpeechPrompt') -and [string]::IsNullOrWhiteSpace($OverflowSharedVoicemailTextToSpeechPrompt)) {
            $null = $PSBoundParameters.Remove('OverflowSharedVoicemailTextToSpeechPrompt')
        }

        if (!$PSBoundParameters.ContainsKey('OverflowSharedVoicemailAudioFilePrompt') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowSharedVoicemailAudioFilePrompt)) {
            $PSBoundParameters.Add('OverflowSharedVoicemailAudioFilePrompt', $existingCallQueue.OverflowSharedVoicemailAudioFilePrompt)
        }
        elseif ($PSBoundParameters.ContainsKey('OverflowSharedVoicemailAudioFilePrompt') -and [string]::IsNullOrWhiteSpace($OverflowSharedVoicemailAudioFilePrompt)) {
            $null = $PSBoundParameters.Remove('OverflowSharedVoicemailAudioFilePrompt')
        }

        if (!$PSBoundParameters.ContainsKey('EnableOverflowSharedVoicemailTranscription')) {
            if ($existingCallQueue.EnableOverflowSharedVoicemailTranscription -ne $null) {
                $PSBoundParameters.Add('EnableOverflowSharedVoicemailTranscription', $existingCallQueue.EnableOverflowSharedVoicemailTranscription)
            }
        }

        if (!$PSBoundParameters.ContainsKey('EnableOverflowSharedVoicemailSystemPromptSuppression') -and $null -ne $existingCallQueue.EnableOverflowSharedVoicemailSystemPromptSuppression) {
            $PSBoundParameters.Add('EnableOverflowSharedVoicemailSystemPromptSuppression',  $existingCallQueue.EnableOverflowSharedVoicemailSystemPromptSuppression)
        }

        if (!$PSBoundParameters.ContainsKey('OverflowActionTarget') -and !($OverflowAction -eq 'Disconnect') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowActionTargetId)) {
            $PSBoundParameters.Add('OverflowActionTarget', $existingCallQueue.OverflowActionTargetId)
        }

        if (!$PSBoundParameters.ContainsKey('OverflowAction')) {
            $PSBoundParameters.Add('OverflowAction', $existingCallQueue.OverflowAction)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutSharedVoicemailTextToSpeechPrompt') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutSharedVoicemailTextToSpeechPrompt) ) {
            $PSBoundParameters.Add('TimeoutSharedVoicemailTextToSpeechPrompt', $existingCallQueue.TimeoutSharedVoicemailTextToSpeechPrompt)
        }
        elseif ($PSBoundParameters.ContainsKey('TimeoutSharedVoicemailTextToSpeechPrompt') -and [string]::IsNullOrWhiteSpace($TimeoutSharedVoicemailTextToSpeechPrompt)) {
            $null = $PSBoundParameters.Remove('TimeoutSharedVoicemailTextToSpeechPrompt')
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutSharedVoicemailAudioFilePrompt') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutSharedVoicemailAudioFilePrompt)) {
            $PSBoundParameters.Add('TimeoutSharedVoicemailAudioFilePrompt', $existingCallQueue.TimeoutSharedVoicemailAudioFilePrompt)
        }
        elseif ($PSBoundParameters.ContainsKey('TimeoutSharedVoicemailAudioFilePrompt') -and [string]::IsNullOrWhiteSpace($TimeoutSharedVoicemailAudioFilePrompt)) {
            $null = $PSBoundParameters.Remove('TimeoutSharedVoicemailAudioFilePrompt')
        }

        if (!$PSBoundParameters.ContainsKey('EnableTimeoutSharedVoicemailTranscription')) {
            if ($existingCallQueue.EnableTimeoutSharedVoicemailTranscription -ne $null) {
                $PSBoundParameters.Add('EnableTimeoutSharedVoicemailTranscription', $existingCallQueue.EnableTimeoutSharedVoicemailTranscription)
            }
        }

        if (!$PSBoundParameters.ContainsKey('EnableTimeoutSharedVoicemailSystemPromptSuppression') -and $null -ne $existingCallQueue.EnableTimeoutSharedVoicemailSystemPromptSuppression) {
            $PSBoundParameters.Add('EnableTimeoutSharedVoicemailSystemPromptSuppression',  $existingCallQueue.EnableTimeoutSharedVoicemailSystemPromptSuppression)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutActionTarget') -and !($TimeoutAction -eq 'Disconnect') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutActionTargetId)) {
            $PSBoundParameters.Add('TimeoutActionTarget', $existingCallQueue.TimeoutActionTargetId)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutAction')) {
            $PSBoundParameters.Add('TimeoutAction', $existingCallQueue.TimeoutAction)
        }

        if (!$PSBoundParameters.ContainsKey('AuthorizedUsers')) {
            $PSBoundParameters.Add('AuthorizedUsers', $existingCallQueue.AuthorizedUsers)
        }

        # End of param hashtable modification

        # Update the CallQueue.
        $updateResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsCallQueue @PSBoundParameters
        # The response of the Update API is only the list of `Diagnostics` which can be directly used in
        # the following method instead of accessing the `Diagnostic` like we do for other CMDLets.
        Write-AdminServiceDiagnostic($updateResult)

        # Unfortunately, CallQueue PUT API does not return a CallQueue DTO model. We need to GET the CallQueue again
        # to print the updated model.
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams

        $updatedCallQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $updatedCallQueue.ParseFrom($getResult.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcBridgeModern

function Set-CsOdcBridgeModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [string]
    ${Name},

    [string]
    ${DefaultServiceNumber},

    [switch]
    ${SetDefault},

    [string]
    ${Identity},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IConferencingBridge]
    [Parameter(ValueFromPipeline)]
    ${Instance},

    [switch]
    ${AsJob})

    process {
        if ($Identity -ne "") {
            # This should map to SetCsOdcBridge_SetExpanded.cs
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge @PSBoundParameters
        }
        elseif ($Name -ne "") {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.BridgeUpdateRequest]::new()

            if ($PSBoundParameters.ContainsKey("DefaultServiceNumber") -and $PSBoundParameters["DefaultServiceNumber"] -ne "") {
                $Body.DefaultServiceNumber = $DefaultServiceNumber
            }

            $Body.SetDefault = $SetDefault

            # This should map to SetCsOdcBridge_Set1.cs
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge -Name $Name -Body $Body
        }
        elseif ($Instance -ne $null) {
           if ($DefaultServiceNumber -eq "" -and !($Instance.DefaultServiceNumber -eq $null)) {
                $DefaultServiceNumber = $Instance.DefaultServiceNumber.Number
           }

           if ($PSBoundParameters.ContainsKey('SetDefault') -eq $false) {
               $SetDefault = $Instance.IsDefault
           }

           $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.BridgeUpdateRequest]::new()

           if ($DefaultServiceNumber -ne "") {
            $Body.DefaultServiceNumber = $DefaultServiceNumber
           }

           $Body.SetDefault = $SetDefault
           $Body.Name = $Instance.Name

           # This should map to SetCsOdcBridge_Set.cs
           $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge -Identity $Instance.Identity -Body $Body
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcServiceNumber

function Set-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [string]
    ${Identity},

    [string]
    ${PrimaryLanguage},

    [string[]]
    ${SecondaryLanguages},

    [switch]
    ${RestoreDefaultLanguages},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [Parameter(ValueFromPipeline)]
    ${Instance})

    process {
        if ($Identity -ne ""){
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null) {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ServiceNumberUpdateRequest]::new()

            if ($PrimaryLanguage -ne "" ){
                $Body.PrimaryLanguage = $PrimaryLanguage
            }
            else {
                $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            }

            if ($SecondaryLanguages -ne "") {
                $Body.SecondaryLanguage = $SecondaryLanguages
            }
            else {
                $Body.SecondaryLanguage = $Instance.SecondaryLanguages
            }

            if ($RestoreDefaultLanguages -eq $true) {
                $Body.RestoreDefaultLanguage = $RestoreDefaultLanguages
            }

            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcServiceNumber -Identity $Instance.Number -Body $Body
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcUserModern

function Set-CsOdcUserModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [System.Object]
    [Parameter(ValueFromPipelineByPropertyName, ValueFromPipeline)]
    ${Identity},

    [string]
    ${TollFreeServiceNumber},

    [string]
    ${BridgeName},

    [switch]
    ${SendEmail},

    [string]
    ${ServiceNumber},

    [string]
    ${SendEmailFromAddress},

    [switch]
    ${Force},

    [switch]
    ${ResetLeaderPin},

    [Alias('DC')]
    ${DomainController},

    [string]
    ${SendEmailToAddress},

    [string]
    ${BridgeId},

    [Nullable[boolean]]
    ${AllowTollFreeDialIn},

    [string]
    ${SendEmailFromDisplayName},

    [switch]
    ${AsJob})

    process {
        if ($Identity -is [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IConferencingUser]){
            $null = $PSBoundParameters.Remove('Identity')
            $PSBoundParameters.Add('Identity', $Identity.Identity)
        }

        # Change from AllowTollFreeDialIn boolean to switch.
        if ($PSBoundParameters.ContainsKey("AllowTollFreeDialIn")){
            $null = $PSBoundParameters.Remove("AllowTollFreeDialIn")
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcUser -AllowTollFreeDialIn:$AllowTollFreeDialIn @PSBoundParameters
        }
        else{
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcUser @PSBoundParameters
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: assign parameters' values and customize output

function Set-CsOnlineSchedule {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Object]
        # The instance of the schedule which is updated.
        ${Instance},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }
        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }
        $params = @{
            Identity = ${Instance}.Id
            Name = ${Instance}.Name
            Type = ${Instance}.Type
            AssociatedConfigurationId = ${Instance}.AssociatedConfigurationId
        }
        # Get common parameters
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $params += @{$p.Key = $p.Value}
        }
        $null = $params.Remove("Instance")

        if (${Instance}.Type -eq [Microsoft.Rtc.Management.Hosted.Online.Models.ScheduleType]::Fixed) {
            $DateTimeRanges = ${Instance}.FixedSchedule.DateTimeRanges
            $dateTimeRangeStandardFormat = 'yyyy-MM-ddTHH:mm:ss';
            $fixedScheduleDateTimeRanges = @()
            foreach ($dateTimeRange in $DateTimeRanges) {
                $fixedScheduleDateTimeRanges += @{
                    Start = $dateTimeRange.Start.ToString($dateTimeRangeStandardFormat, [System.Globalization.CultureInfo]::InvariantCulture)
                    End = $dateTimeRange.End.ToString($dateTimeRangeStandardFormat, [System.Globalization.CultureInfo]::InvariantCulture)
                }
            }
            $params['FixedScheduleDateTimeRange'] = $fixedScheduleDateTimeRanges
        }

        if (${Instance}.Type -eq [Microsoft.Rtc.Management.Hosted.Online.Models.ScheduleType]::WeeklyRecurrence) {
            $MondayHours = ${Instance}.WeeklyRecurrentSchedule.MondayHours
            $TuesdayHours = ${Instance}.WeeklyRecurrentSchedule.TuesdayHours
            $WednesdayHours = ${Instance}.WeeklyRecurrentSchedule.WednesdayHours
            $ThursdayHours = ${Instance}.WeeklyRecurrentSchedule.ThursdayHours
            $FridayHours = ${Instance}.WeeklyRecurrentSchedule.FridayHours
            $SaturdayHours = ${Instance}.WeeklyRecurrentSchedule.SaturdayHours
            $SundayHours = ${Instance}.WeeklyRecurrentSchedule.SundayHours

            if ($MondayHours -ne $null -and $MondayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleMondayHour'] = @()
                foreach ($mondayHour in $MondayHours){
                    $params['WeeklyRecurrentScheduleMondayHour'] += @{
                        Start = $mondayHour.Start
                        End = $mondayHour.End
                    }
                }
            }
            if ($TuesdayHours -ne $null -and $TuesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleTuesdayHour'] = @()
                foreach ($tuesdayHour in $TuesdayHours){
                    $params['WeeklyRecurrentScheduleTuesdayHour'] += @{
                        Start = $tuesdayHour.Start
                        End = $tuesdayHour.End
                    }
                }
            }
            if ($WednesdayHours -ne $null -and $WednesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleWednesdayHour'] = @()
                foreach ($wednesdayHour in $WednesdayHours){
                    $params['WeeklyRecurrentScheduleWednesdayHour'] += @{
                        Start = $wednesdayHour.Start
                        End = $wednesdayHour.End
                    }
                }    
            }
            if ($ThursdayHours -ne $null -and $ThursdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleThursdayHour'] = @()
                    foreach ($thursdayHour in $ThursdayHours){
                        $params['WeeklyRecurrentScheduleThursdayHour'] += @{
                            Start = $thursdayHour.Start
                            End = $thursdayHour.End
                    }
                }
            }
            if ($FridayHours -ne $null -and $FridayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleFridayHour'] = @()
                foreach ($fridayHour in $FridayHours){
                    $params['WeeklyRecurrentScheduleFridayHour'] += @{
                        Start = $fridayHour.Start
                        End = $fridayHour.End
                    }
                }
            }
            if ($SaturdayHours -ne $null -and $SaturdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSaturdayHour'] = @()
                foreach ($saturdayHour in $SaturdayHours){
                    $params['WeeklyRecurrentScheduleSaturdayHour'] += @{
                        Start = $saturdayHour.Start
                        End = $saturdayHour.End
                    }
                }
            }
            if ($SundayHours -ne $null -and $SundayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSundayHour'] = @()
                foreach ($sundayHour in $SundayHours){
                    $params['WeeklyRecurrentScheduleSundayHour'] += @{
                        Start = $sundayHour.Start
                        End = $sundayHour.End
                    }
                }
            }

            $params['WeeklyRecurrentScheduleIsComplemented'] = ${Instance}.WeeklyRecurrentSchedule.ComplementEnabled
            
            if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange -ne $null) {
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Start -ne $null) { $params['RecurrenceRangeStart'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Start }
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.End -ne $null) { $params['RecurrenceRangeEnd'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.End }
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Type -ne $null) { $params['RecurrenceRangeType'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Type }
            }
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineSchedule @params

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
        $schedule.ParseFrom($result)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Set-CsOnlineVoicemailUserSettings {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
    [Parameter(Position=0, Mandatory)]
    [System.String]
    ${Identity},

    [Parameter()]
    [Microsoft.Rtc.Management.Hosted.Voicemail.Models.CallAnswerRules]
    ${CallAnswerRule},

    [Parameter()]
    [System.String]
    ${DefaultGreetingPromptOverwrite},

    [Parameter()]
    [System.String]
    ${DefaultOofGreetingPromptOverwrite},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingEnabled},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingFollowAutomaticRepliesEnabled},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingFollowCalendarEnabled},

    [Parameter()]
    [System.String]
    ${PromptLanguage},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${ShareData},

    [Parameter()]
    [System.String]
    ${TransferTarget},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${VoicemailEnabled},

    [Parameter(Mandatory=$false)]
    [Switch]
    ${Force}

    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }
        
        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineVMUserSetting @PSBoundParameters
        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        # If none of the above parameters are set (except Identity and Force), 
        # We should display the Warning message to user.
        if ($PSBoundParameters["CallAnswerRule"] -eq $null -and
            $PSBoundParameters["DefaultGreetingPromptOverwrite"] -eq $null -and
            $PSBoundParameters["DefaultOofGreetingPromptOverwrite"] -eq $null -and 
            $PSBoundParameters["OofGreetingEnabled"] -eq $null -and
            $PSBoundParameters["OofGreetingFollowAutomaticRepliesEnabled"] -eq $null -and
            $PSBoundParameters["OofGreetingFollowCalendarEnabled"] -eq $null -and
            $PSBoundParameters["PromptLanguage"] -eq $null -and
            $PSBoundParameters["ShareData"] -eq $null -and
            $PSBoundParameters["TransferTarget"] -eq $null -and 
            $PSBoundParameters["VoicemailEnabled"] -eq $null) {
                Write-Warning("To set online voicemail user settings for user {0}, at least one optional parameter should be provided." -f $Identity)
        }

        $result
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Update-CsAutoAttendant {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be updated.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Update-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Provide common functions for voice app team cmdlets

function Write-AdminServiceDiagnostic {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IDiagnosticRecord[]]
        # The diagnostic object
        ${Diagnostics}
    )
    process {
        if ($Diagnostics -eq $null)
        {
            return
        }

        foreach($diagnostic in $Diagnostics)
        {
            if ($diagnostic.Level -eq $null)
            {
                Write-Output $diagnostic.Message
            }
            else
            {
                switch($diagnostic.Level)
                {
                    "Warning" { Write-Warning $diagnostic.Message }
                    "Info" { Write-Output $diagnostic.Message }
                    "Verbose" { Write-Verbose $diagnostic.Message }
                    default { Write-Output $diagnostic.Message }
                }
            }
        }
    }
}

function Get-StatusRecordStatusString {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Int]
        # The int status from status record
        ${StatusRecordStatus}
    )
    process {
        if ($StatusRecordStatus -eq $null)
        {
            return
        }

        $status = ''

        switch ($StatusRecordStatus)
        {
            0 {$status = 'Error'}
            1 {$status = 'Pending'}
            2 {$status = 'Unknown'}
            3 {$status = 'Success'}
        }

        $status
    }
}

function Get-StatusRecordStatusCodeString {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Int]
        # The int status from status record
        ${StatusRecordErrorCode}
    )
    process {
        if ($StatusRecordErrorCode -eq $null)
        {
            return
        }

        $statusCode = ''

        switch ($StatusRecordErrorCode)
        {
            'ApplicationInstanceAssociationProvider_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'ApplicationInstanceAssociationStatusProvider_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'ApplicationInstanceAssociationStatusProvider_AcsAssociationNotFound' {$statusCode = 'AcsAssociationNotFound'}
            'ApplicationInstanceAssociationStatusProvider_ApsAssociationNotFound' {$statusCode = 'ApsAppEndpointNotFound'}
            'AudioFile_FileNameNullOrWhitespace' {$statusCode = 'AudioFileNameNullOrWhitespace'}
            'AudioFile_FileNameTooShort' {$statusCode = 'AudioFileNameTooShort'}
            'AudioFile_FileNameTooLong' {$statusCode = 'AudioFileNameTooLong'}
            'AudioFile_InvalidAudioFileExtension' {$statusCode = 'InvalidAudioFileExtension'}
            'AudioFile_InvalidFileName' {$statusCode = 'InvalidAudioFileName'}
            'AudioFile_UnsupportedAudioFileExtension' {$statusCode = 'UnsupportedAudioFileExtension'}
            'CreateApplicationEndpoint_ApsAppEndpointInvalid' {$statusCode = 'ApsAppEndpointInvalid'}
            'CreateApplicationInstanceAssociation_AppEndpointAlreadyAssociated' {$statusCode = 'AcsAssociationAlreadyExists'}
            'CreateApplicationInstanceAssociation_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'CreateApplicationInstanceAssociation_AppEndpointMissingProvisioning' {$statusCode = 'AppEndpointMissingProvisioning'}
            'DateTimeRange_InvalidDateTimeRangeBound' {$statusCode = 'InvalidDateTimeRangeFormat'}
            'DateTimeRange_InvalidDateTimeRangeKind' {$statusCode = 'InvalidDateTimeRangeKind'}
            'DateTimeRange_NonPositiveDateTimeRange' {$statusCode = 'InvalidDateTimeRange'}
            'DeserializeScheduleOperation_InvalidModelVersion' {$statusCode = 'InvalidSerializedModelVersion'}
            'EnvironmentContextMapper_ForestNameNullOrWhiteSpace' {$statusCode = 'ForestNameNullOrWhiteSpace'}
            'FixedSchedule_DuplicateDateTimeRangeStartBoundaries' {$statusCode = 'DuplicateDateTimeRangeStartBoundaries'}
            'FixedSchedule_InvalidDateTimeRangeBoundariesAlignment' {$statusCode = 'InvalidDateTimeRangeBoundariesAlignment'}
            'ModelId_InvalidScheduleId' {$statusCode = 'InvalidScheduleId'}
            'ModifyScheduleOperation_ScheduleConflictInExistingAutoAttendant' {$statusCode = 'ScheduleConflictInExistingAutoAttendant'}
            'RemoveApplicationInstanceAssociation_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'RemoveApplicationInstanceAssociation_AssociationNotFound' {$statusCode = 'AcsAssociationNotFound'}
            'RemoveScheduleOperation_ScheduleInUse' {$statusCode = 'ScheduleInUse'}
            'Schedule_NameNullOrWhitespace' {$statusCode = 'ScheduleNameNullOrWhitespace'}
            'Schedule_NameTooLong' {$statusCode = 'ScheduleNameTooLong'}
            'Schedule_FixedScheduleNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_FixedScheduleNonNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_WeeklyRecurrentScheduleNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_WeeklyRecurrentScheduleNonNull' {$statusCode = 'ScheduleTypeMismatch'}
            'ScheduleRecurrenceRange_InvalidType' {$statusCode = 'InvalidRecurrenceRangeType'}
            'ScheduleRecurrenceRange_UnsupportedType' {$statusCode = 'InvalidRecurrenceRangeType'}
            'ScheduleRecurrenceRange_NonPositiveRange' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_EndDateTimeNull' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_EndDateTimeNonNull' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesZero' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesNull' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesNonNull' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'TimeRange_InvalidTimeRange' {$statusCode = 'InvalidTimeRange'}
            'TimeRange_InvalidTimeRangeBound' {$statusCode = 'InvalidTimeRangeBound'}
            'WeeklyRecurrentSchedule_EmptySchedule' {$statusCode = 'EmptyWeeklyRecurrentSchedule'}
            'WeeklyRecurrentSchedule_InvalidTimeRangeBoundariesAlignment' {$statusCode = 'InvalidTimeRangeBoundariesAlignment'}
            'WeeklyRecurrentSchedule_OverlappingTimeRanges' {$statusCode = 'TimeRangesOverlapping'}
            'WeeklyRecurrentSchedule_TooManyTimeRangesPerDay' {$statusCode = 'TooManyTimeRangesForDay'}
            'WeeklyRecurrentSchedule_RecurrenceRangeNull' {$statusCode = 'ScheduleRecurrenceRangeNull'}
        }

        $statusCode
    }
}

# Asp.Net 4.0+ considers these eight characters (<, >, *, %, &, :, \, and ?) as the default
# potential dangerous characters in the URL which may be used in XSS attacks.
# A SIP URI (sip:user@domain.com:port) usually startswith SIP prefix (sip:). This COLON (:)
# in prefix needs to be replaced with something that is not invalid.
# Also, as the last parameter in the URI is "identity", it can not have Dots (.)
# For these reasons we wrote this custom method.
function EncodeSipUri {
    param(
        $Identity
    )

    if ($Identity -eq $null)
    {
        return
    }

    $Identity = $Identity.replace(':', "[COLON]")
    $Identity = $Identity.replace('.', "[DOT]")

    return $Identity
}

# SIG # Begin signature block
# MIInlgYJKoZIhvcNAQcCoIInhzCCJ4MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAKiJTzTqfzMFxm
# /wvuZKWBsbY/A4h/cEhE2N0SjOWzGqCCDWgwggXmMIIDzqADAgECAhMzAAACmxMC
# go/zkE7SAAAAAAKbMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwMTI3MTkzNjA5WhcNMjMwMTI2MTkzNjA5WjByMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMRwwGgYDVQQDExNTa3lw
# ZSBTb2Z0d2FyZSBTYXJsMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# u+NiUPx3qvnOsElGlwVWN0eTqguFi4rLsXmjKWB8JiVD0zpkdlWiaPOm4e6FZPhj
# lVg8G9DHHr8ujVpylpghyIRd5cubBTIo/sRIhDQCD3OclsNyE3IZTRTABn7A8xbA
# HnjFL56J+eXOJRZX7+FLwBNB0ZCFTSQZBKxL65w/Tb4HZ81sUQmVa5dE1OHKO6jU
# xHe2ODTatidrCSHuJ0FAGwn0gR08xlOIMN6/BReIrvG+2OXfTUO+XcZOf1cgctCN
# zFCJNSuw4ga7qwuSZc7JRk1jPlotE/4+OZFx5v7Wz0ysP3IiKK67JeL41pvFFWGy
# Ds5gHu19Y9K9j5T1vW/xMQIDAQABo4IBZzCCAWMwEwYDVR0lBAwwCgYIKwYBBQUH
# AwMwHQYDVR0OBBYEFHKvVX1Sg3XuLgPmjE5+VQh3X2a4MEUGA1UdEQQ+MDykOjA4
# MR4wHAYDVQQLExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xFjAUBgNVBAUTDTIzMDI1
# NCs0NjkwNzUwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0f
# BE0wSzBJoEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwv
# TWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMw
# UQYIKwYBBQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAA
# MA0GCSqGSIb3DQEBCwUAA4ICAQBK/psBUS/OeLPHeeos1A5DK/NgU16+/ptZoQBO
# 5UCl48UenZSZ2k7Yicmpc7uyMtsVKWr54aSRdGfg4eRg5QF7GIrsyPeJa+a+DaCN
# JW9dM1o0D/HodrnmHFtTX/VJl6pxf64x16iiUhbzV+UtHorlxMwiKkkQTEwLgtWK
# WIck8V9WnpDqKq9N3YhfFGYaFxW7U++GOBrju45TYjY+n4x1QnxXn1vBxKQiXkyH
# unP35jZ5kZUD/6JHKOFWlwQj1fvvhdvUq4Nl3kryoY4kLrbd5eUIkeRHATiOiqUt
# +gn49qFAz5n87Xz4fxNIsaL7NPN9UShNMi8eXf+WBT0Jw82eE8fn1fR5+QBtyU3R
# 6IPZ8udQ67UIbYiMG4VJO95tB8Xuqlv+ovsKZSZ9wTrFc/tbESQkMdPbilFwDLK9
# BEdHGwBRP0o9vsR7IPF7Rc8xlAGqWjDIGgfGPDpied3gvJD49JN0Nrw8iNR1hY6l
# wYtFIdm/Rbr78J2CuH49vToXw3RqM62+x8TpqHYfDzKEzi38Y8+elqzz2LAbE0tL
# S2tvl0pjaiLSEbfzyhbo7S/6k5GgPkEmMgqr1x4uZufBz4lCy5JsJM7IJAO7nF7q
# j6jyaKWHzHEkvSuAVpVgKiz4zT4ZOuH7tUT6qBbdFyPD9XYcpfPi80mH5MwJSZcC
# UqVqTjCCB3owggVioAMCAQICCmEOkNIAAAAAAAMwDQYJKoZIhvcNAQELBQAwgYgx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1p
# Y3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDExMB4XDTExMDcw
# ODIwNTkwOVoXDTI2MDcwODIxMDkwOVowfjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EgMjAxMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKvw+nIQHC6t
# 2G6qghBNNLrytlghn0IbKmvpWlCquAY4GgRJun/DDB7dN2vGEtgL8DjCmQawyDnV
# ARQxQtOJDXlkh36UYCRsr55JnOloXtLfm1OyCizDr9mpK656Ca/XllnKYBoF6WZ2
# 6DJSJhIv56sIUM+zRLdd2MQuA3WraPPLbfM6XKEW9Ea64DhkrG5kNXimoGMPLdNA
# k/jj3gcN1Vx5pUkp5w2+oBN3vpQ97/vjK1oQH01WKKJ6cuASOrdJXtjt7UORg9l7
# snuGG9k+sYxd6IlPhBryoS9Z5JA7La4zWMW3Pv4y07MDPbGyr5I4ftKdgCz1TlaR
# ITUlwzluZH9TupwPrRkjhMv0ugOGjfdf8NBSv4yUh7zAIXQlXxgotswnKDglmDlK
# Ns98sZKuHCOnqWbsYR9q4ShJnV+I4iVd0yFLPlLEtVc/JAPw0XpbL9Uj43BdD1FG
# d7P4AOG8rAKCX9vAFbO9G9RVS+c5oQ/pI0m8GLhEfEXkwcNyeuBy5yTfv0aZxe/C
# HFfbg43sTUkwp6uO3+xbn6/83bBm4sGXgXvt1u1L50kppxMopqd9Z4DmimJ4X7Iv
# hNdXnFy/dygo8e1twyiPLI9AN0/B4YVEicQJTMXUpUMvdJX3bvh4IFgsE11glZo+
# TzOE2rCIF96eTvSWsLxGoGyY0uDWiIwLAgMBAAGjggHtMIIB6TAQBgkrBgEEAYI3
# FQEEAwIBADAdBgNVHQ4EFgQUSG5k5VAF04KqFzc3IrVtqMp1ApUwGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8w
# HwYDVR0jBBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0fBFMwUTBPoE2g
# S4ZJaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWlj
# Um9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcBAQRSMFAwTgYI
# KwYBBQUHMAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWlj
# Um9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNydDCBnwYDVR0gBIGXMIGUMIGRBgkr
# BgEEAYI3LgMwgYMwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvZG9jcy9wcmltYXJ5Y3BzLmh0bTBABggrBgEFBQcCAjA0HjIgHQBM
# AGUAZwBhAGwAXwBwAG8AbABpAGMAeQBfAHMAdABhAHQAZQBtAGUAbgB0AC4gHTAN
# BgkqhkiG9w0BAQsFAAOCAgEAZ/KGpZjgVHkaLtPYdGcimwuWEeFjkplCln3SeQyQ
# wWVfLiw++MNy0W2D/r4/6ArKO79HqaPzadtjvyI1pZddZYSQfYtGUFXYDJJ80hpL
# HPM8QotS0LD9a+M+By4pm+Y9G6XUtR13lDni6WTJRD14eiPzE32mkHSDjfTLJgJG
# KsKKELukqQUMm+1o+mgulaAqPyprWEljHwlpblqYluSD9MCP80Yr3vw70L01724l
# ruWvJ+3Q3fMOr5kol5hNDj0L8giJ1h/DMhji8MUtzluetEk5CsYKwsatruWy2dsV
# iFFFWDgycScaf7H0J/jeLDogaZiyWYlobm+nt3TDQAUGpgEqKD6CPxNNZgvAs031
# 4Y9/HG8VfUWnduVAKmWjw11SYobDHWM2l4bf2vP48hahmifhzaWX0O5dY0HjWwec
# hz4GdwbRBrF1HxS+YWG18NzGGwS+30HHDiju3mUv7Jf2oVyW2ADWoUa9WfOXpQlL
# SBCZgB/QACnFsZulP0V3HjXG0qKin3p6IvpIlR+r+0cjgPWe+L9rt0uX4ut1eBrs
# 6jeZeRhL/9azI2h15q/6/IvrC4DqaTuv/DDtBEyO3991bWORPdGdVk5Pv4BXIqF4
# ETIheu9BCrE/+6jMpF3BoYibV3FWTkhFwELJm3ZbCoBIa/15n8G9bW1qyVJzEw16
# UM0xghmEMIIZgAIBATCBlTB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDEx
# AhMzAAACmxMCgo/zkE7SAAAAAAKbMA0GCWCGSAFlAwQCAQUAoIGmMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCDYRDKhFM4sJ5DLnIKly6jFFs7h38H1cnvOiFViC+Af
# ZDA6BgorBgEEAYI3AgEMMSwwKqAMgAoAUwBrAHkAcABloRqAGGh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQA22uTOnIKxku9zduFw5AeS
# lawVts2BRv5/3I3MCAM45lhswZStGuJ+Lp2HaHPfXX6DHmE3p24Z/KIZ6wwyhTFJ
# tW/aphL44AXt/RlKCaQFSRPdwnyZ9YxWlCi5kUZSx7Pb0uE9/jGaxbEQRXXhPQyj
# IZ3idQosuhSxn/Gz3a3bHy8Z9eQ1B8XSMYkNcqStuJZ/sP+/IMgRjAZilZONwccZ
# rkJX2+aw5FrLARzrUAG+VFZVnL+6+ayuElX7BfkgfXqIkLTQG7Wvv+MI7J66uAVe
# W3d1TIgRyiXK8lg0ykITVKeOvCTRx1y122IY644pkcMmrUTj1T2dc7u5RdJSTlLy
# oYIXFjCCFxIGCisGAQQBgjcDAwExghcCMIIW/gYJKoZIhvcNAQcCoIIW7zCCFusC
# AQMxDzANBglghkgBZQMEAgEFADCCAVkGCyqGSIb3DQEJEAEEoIIBSASCAUQwggFA
# AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIOlQuQ6XdF7AXq94yZex
# G1bJM//0l30snmrBpbfPaOMUAgZi3ohAo10YEzIwMjIwNzI5MDk0NjU0Ljk5Mlow
# BIACAfSggdikgdUwgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRl
# ZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDA4Mi00QkZELUVFQkExJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghFlMIIHFDCCBPygAwIB
# AgITMwAAAY/zUajrWnLdzAABAAABjzANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMTEwMjgxOTI3NDZaFw0yMzAxMjYxOTI3
# NDZaMIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYD
# VQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNV
# BAsTHVRoYWxlcyBUU1MgRVNOOkQwODItNEJGRC1FRUJBMSUwIwYDVQQDExxNaWNy
# b3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEAmVc+/rXPFx6Fk4+CpLrubDrLTa3QuAHRVXuy+zsxXwkogkT0a+XW
# uBabwHyqj8RRiZQQvdvbOq5NRExOeHiaCtkUsQ02ESAe9Cz+loBNtsfCq846u3ot
# WHCJlqkvDrSr7mMBqwcRY7cfhAGfLvlpMSojoAnk7Rej+jcJnYxIeN34F3h9JwAN
# Y360oGYCIS7pLOosWV+bxug9uiTZYE/XclyYNF6XdzZ/zD/4U5pxT4MZQmzBGvDs
# +8cDdA/stZfj/ry+i0XUYNFPhuqc+UKkwm/XNHB+CDsGQl+ZS0GcbUUun4VPThHJ
# m6mRAwL5y8zptWEIocbTeRSTmZnUa2iYH2EOBV7eCjx0Sdb6kLc1xdFRckDeQGR4
# J1yFyybuZsUP8x0dOsEEoLQuOhuKlDLQEg7D6ZxmZJnS8B03ewk/SpVLqsb66U2q
# yF4BwDt1uZkjEZ7finIoUgSz4B7fWLYIeO2OCYxIE0XvwsVop9PvTXTZtGPzzmHU
# 753GarKyuM6oa/qaTzYvrAfUb7KYhvVQKxGUPkL9+eKiM7G0qenJCFrXzZPwRWoc
# cAR33PhNEuuzzKZFJ4DeaTCLg/8uK0Q4QjFRef5n4H+2KQIEibZ7zIeBX3jgsrIC
# bzzSm0QX3SRVmZH//Aqp8YxkwcoI1WCBizv84z9eqwRBdQ4HYcNbQMMCAwEAAaOC
# ATYwggEyMB0GA1UdDgQWBBTzBuZ0a65JzuKhzoWb25f7NyNxvDAfBgNVHSMEGDAW
# gBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0
# YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUF
# BzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jv
# c29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4ICAQDNf9Oo
# 9zyhC5n1jC8iU7NJY39FizjhxZwJbJY/Ytwn63plMlTSaBperan566fuRojGJSv3
# EwZs+RruOU2T/ZRDx4VHesLHtclE8GmMM1qTMaZPL8I2FrRmf5Oop4GqcxNdNECB
# ClVZmn0KzFdPMqRa5/0R6CmgqJh0muvImikgHubvohsavPEyyHQa94HD4/LNKd/Y
# IaCKKPz9SA5fAa4phQ4Evz2auY9SUluId5MK9H5cjWVwBxCvYAD+1CW9z7GshJlN
# jqBvWtKO6J0Aemfg6z28g7qc7G/tCtrlH4/y27y+stuwWXNvwdsSd1lvB4M63AuM
# l9Yp6au/XFknGzJPF6n/uWR6JhQvzh40ILgeThLmYhf8z+aDb4r2OBLG1P2B6aCT
# W2YQkt7TpUnzI0cKGr213CbKtGk/OOIHSsDOxasmeGJ+FiUJCiV15wh3aZT/VT/P
# kL9E4hDBAwGt49G88gSCO0x9jfdDZWdWGbELXlSmA3EP4eTYq7RrolY04G8fGtF0
# pzuZu43A29zaI9lIr5ulKRz8EoQHU6cu0PxUw0B9H8cAkvQxaMumRZ/4fCbqNb4T
# cPkPcWOI24QYlvpbtT9p31flYElmc5wjGplAky/nkJcT0HZENXenxWtPvt4gcoqp
# peJPA3S/1D57KL3667epIr0yV290E2otZbAW8DCCB3EwggVZoAMCAQICEzMAAAAV
# xedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENl
# cnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkz
# MDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH
# 0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPP
# dzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlh
# AnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP
# 1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVV
# mG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakX
# W2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+
# Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9
# Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdj
# bwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S
# 2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57
# t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEE
# AYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJd
# g/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYB
# BQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBv
# c2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4K
# AFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSME
# GDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRw
# Oi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJB
# dXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5o
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvh
# nnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGU
# GCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZ
# GN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFd
# PSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7
# bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxy
# bxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJ
# VGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S
# 0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGE
# vL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurw
# J0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2l
# BRDBcQZqELQdVTNYs6FwZvKhggLUMIICPQIBATCCAQChgdikgdUwgdIxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29m
# dCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRT
# UyBFU046RDA4Mi00QkZELUVFQkExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAD5NL4IEdudIBwdGoCaV0WBbQZpq
# oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcN
# AQEFBQACBQDmjaO6MCIYDzIwMjIwNzI5MDgwOTMwWhgPMjAyMjA3MzAwODA5MzBa
# MHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOaNo7oCAQAwBwIBAAICCeowBwIBAAIC
# EVYwCgIFAOaO9ToCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAK
# MAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQB7Yb+xNk5W
# lTqmQzi96LXxzFLdu5KOwM2ufQjapu1SiWbiBQcK+UzuDb43YTyXMbaAzCSnm5Dq
# 91MnMBnsbyHE7Osr5pvdHnewTcfYfL6UrIFmniERNvxPlzY113cmvbSvevjyJ+5U
# 4/Iy0nyZbt3h9nDxERzt1em2RgD1asJx9TGCBA0wggQJAgEBMIGTMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABj/NRqOtact3MAAEAAAGPMA0GCWCG
# SAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZI
# hvcNAQkEMSIEIP8r9QkfEuX6f5rW8NYGU3wbluzHu3V0lhyfXG5kuKoHMIH6Bgsq
# hkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgl3IFT+LGxguVjiKm22ItmO6dFDWW8nSh
# u6O6g8yFxx8wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAY/zUajrWnLdzAABAAABjzAiBCD7dxTtWwbopvw7oysOoAhOOwlyGF0r50gq
# cn8oKgOUrTANBgkqhkiG9w0BAQsFAASCAgBkClAIUFgtVzMPljx2SlNt+mHwOD7T
# tWBZh3mzYC3vccqA/nECy34i53D6wan5VrIrTlE18DZS2cSJU+r0B0YK4n+jt7z3
# wA7y19hqwJpgAVOSrx+4S3+9pVhZkknWP/R9WyH07Wj/cFMLVTbjfqZE5MkD/VUs
# FfPtUApTZ6ThiNCOj/3/mBBGn2XyWlDpgTXVudvWHe7kI9MN7PFOYPcjRdHcUhKN
# cygq5AAZy3fGgx4aGs0/SlLRyqQjX9NS9MFXKDCBxysCLSpV9d5eMPcJX0nOzom0
# A6Jdb424bDqenEwFjEtMCCSI3B/nHsyF3mtDgYZMzRyfa1TCsVCuPW3iRJzwVFA4
# 6YI2pVQAiQjQNOKpo1XGc54yDoJ+65KSi5o9NG9pyDE/COWjaajAI8NhRK64TN9H
# Zbepp6AsB3alx3IDIuTgM7J2JHOlZs0Ehu9EHDSGg9qC8mlpWQOLM1BkS/NrGGXP
# //G4doj8CYjRUMeVKDc8xAbCA54oWDL912TRcUfmCrjkzN9qlFxmgPLFzoH5G23u
# yISbZ0sv2u4QxGzVWYhUXfrx/GA08fxzGWwHDc6cVRakmbQ5A5gt0DOoa/jebWnX
# rWLSDNU6XYovu1tWEybuTYZMevfzFIOj4a2qra53t9M4gDbNmPcsoRYhg4Ps+Yt9
# gxwh66gdaJgM8A==
# SIG # End signature block
